import { registerRootComponent } from 'expo';
import MainNavigator from "./source/navigation";
import { CombineContextProvider } from './source/context.js/index.js';
import { AdminNavigator } from './source/admin';
import { AdminAuthContextProvider } from './source/admin/context/admin_auth_context';
import { useState } from 'react';


export default function App() {
    const [admin, setAdmin] = useState(false);
    
    if (admin) {
        return (
            <AdminAuthContextProvider>
                <AdminNavigator />
            </AdminAuthContextProvider>
        )
    } else {
        return (
            <CombineContextProvider>
                <MainNavigator />
            </CombineContextProvider>
        )
    }

}

registerRootComponent(App);
