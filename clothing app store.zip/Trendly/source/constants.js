const colors = {
    background: "#EDEDED",
    card: "#FAFAFA",
    buttons: "#3A86FF",
    buttonText: "#FFFFFF",
    text: "#4A4A4A",
    inputBackground: "#F7F7F7",
    inputText: "#333333",
    border: "#DDDDDD"
}

const regexs = {
    emailRegex: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
    nameRegex: /^[a-zA-Z\s'-]{1,50}$/,
    phoneRegex: /^(\+92|0)?3[0-9]{2}[0-9]{7}$/,
    ageRegex: /^([1-9][0-9]?|1[01][0-9]|120)$/,
}


const productImages = {
    "1": { id: "1", path: require('./assets/images/products/1.jpeg') },
    "2": { id: "2", path: require('./assets/images/products/2.jpeg') },
    "3": { id: "3", path: require('./assets/images/products/3.jpeg') },
    "4": { id: "4", path: require('./assets/images/products/4.jpeg') },
    "5": { id: "5", path: require('./assets/images/products/5.jpeg') },
    "6": { id: "6", path: require('./assets/images/products/6.jpeg') },
    "7": { id: "7", path: require('./assets/images/products/7.jpeg') },
    "8": { id: "8", path: require('./assets/images/products/8.jpeg') },
    "9": { id: "9", path: require('./assets/images/products/9.jpeg') },
    "10": { id: "10", path: require('./assets/images/products/10.jpeg') },
}

const firebase = {
    API_KEY: "AIzaSyDCcdHSWpbITIrURpggtdvYzV6hJ_9Jh4E",
    auth_url: "https://identitytoolkit.googleapis.com/v1/accounts:",
    db: "https://trendly-1c44d-default-rtdb.firebaseio.com/",
}
export const constants = {
    colors,
    regexs,
    firebase,
    productImages
}