import { utils } from "../shared";

export async function getCategories(token, setCategories) {
    try {
        const response = await utils.axiosRequests.read(token, `Categories`);
        if (response.success) {
            let tempCategories = {}
            response.data.forEach((item, index) => {
                if (item) {
                    tempCategories[item.id] = item
                }
            })
            setCategories(tempCategories);
        } else {
            console.log('Error getting categories Axios utils error')
        }
    } catch (error) {
        console.log('Error getting categories', error)
    }
}