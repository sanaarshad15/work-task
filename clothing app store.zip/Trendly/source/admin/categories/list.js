import React, { useState, useEffect } from "react";
import { View, StyleSheet, FlatList } from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { Components, constants, useAdmineAuthContext } from "../shared";
import { getCategories } from "./function";



export default function ListCategory({ navigation, route }) {

    const [categories, setCategories] = useState({});
    const { admintoken } = useAdmineAuthContext();

    useEffect(() => {
        if (admintoken) {
            getCategories(admintoken, setCategories)
        }
    }, [admintoken])

    return (
        <View style={[styles.container]}>
            <View style={[styles.header]}>
                <Components.Buttons.TextButton
                    text={'Add'}
                    onPress={() => {
                        navigation.navigate('addcategory', {
                            setCategories: setCategories,
                            id: categories && Object.keys(categories).length > 0
                                ? Math.max(...Object.keys(categories).map(Number)) + 1
                                : 1,
                            name: undefined
                        })
                    }}
                    buttonStyle={styles.addButton}
                />
            </View>
            <View style={[styles.body]}>
                <FlatList
                    data={Object.keys(categories)}
                    keyExtractor={(item, index) => item}
                    renderItem={({ item, index }) => (
                        <View style={[styles.cateogory]}>
                            <Components.Text.ButtonText
                                text={categories[item].name}
                                textStyle={styles.categoryText}
                            />
                            <MaterialIcons
                                name="edit"
                                size={20}
                                color={'tomato'}
                                onPress={() => {
                                    navigation.navigate('addcategory', {
                                        setCategories: setCategories,
                                        id: categories[item].id,
                                        name: categories[item].name
                                    })
                                }}
                            />
                        </View>
                    )}
                />
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background
    },
    header: {
        flex: 0.15,
        justifyContent: "center",
        alignItems: "center"
    },
    addButton: {
        marginTop: 30,
        width: "90%",
    },
    body: {
        flex: 0.85,
        paddingHorizontal: 20,
    },
    cateogory: {
        marginVertical: 5,
        paddingHorizontal: 10,
        paddingVertical: 7,
        width: "100%",
        borderRadius: 4,
        backgroundColor: constants.colors.inputBackground,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },
    categoryText: {
        color: constants.colors.inputText
    },
    category_icon: {

    }
})