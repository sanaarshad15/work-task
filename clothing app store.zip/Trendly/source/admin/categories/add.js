import React, { useRef, useState } from "react";
import { View, StyleSheet, Alert } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import {
    Components, constants,
    utils,
    useAdmineAuthContext
} from "../shared";


export default function AddCategory({ navigation, route }) {
    const [loading, setLoading] = useState(false)
    const { admintoken } = useAdmineAuthContext();


    const [name, setName] = useState(route.params.name);
    const nameRef = useRef(null)
    const id = route.params.id

    function handleSuccess(data) {
        route.params.setCategories((prevData) => ({
            ...prevData,
            [data.id]: data
        }))
        nameRef.current.clear();
        setName();
        navigation.goBack();
        setLoading(false);

    }
    //  add/update category
    async function add() {
        setLoading(true);
        if (name && name.length > 0) {
            const data = {
                name: name,
                id: id
            }
            if (admintoken) {
                let response;
                if (route.params.name !== undefined) {
                    response = await utils.axiosRequests.update(admintoken, `Categories/${id}`, data)
                } else {
                    response = await utils.axiosRequests.create(admintoken, `Categories/${id}`, data)
                }
                if (response && response.success) {
                    Alert.alert('Success', `Category ${route.params.name ? 'updated' : 'added'} successfully.`);
                    handleSuccess(response.data);
                } else {
                    Alert.alert('Error', `Unable to ${route.params.name ? 'update' : 'add'} category`)
                    setLoading(false)
                }
            } else {
                Alert.alert("Error", 'You are not authorized, Please try again.');
                setLoading(false);
            }
        } else {
            Alert.alert("Error", "Please enter a valid category name");
            setLoading(false);
        }
        setLoading(false);
    }


    return (
        <View style={[styles.container]}>
            <View style={[styles.header]}>
                <Components.Buttons.IconButton
                    Icon={<Ionicons
                        name="arrow-back-outline"
                        size={16}
                        color={constants.colors.buttonText}
                    />}
                    onPress={() => {
                        nameRef.current.clear();
                        setName();
                        navigation.goBack()
                    }}
                />
                <Components.Text.Heading
                    text={route.params.name !== undefined ? "Edit Category" : "Add Category"}
                />
                <View />
            </View>
            <View style={[styles.body]}>
                <Components.Inputs.Input
                    onChangeText={setName}
                    ref={nameRef}
                    style={styles.input}
                    placeholder={'Category name'}
                    value={name}
                />
                <Components.Buttons.TextButton
                    text={route.params.name !== undefined ? 'Update' : 'Add'}
                    onPress={add}
                    buttonStyle={styles.button}
                />
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background
    },
    header: {
        flex: 0.15,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingHorizontal: 10,
        paddingTop: 10
    },
    body: {
        flex: 0.85,
        paddingHorizontal: 20,
        paddingTop: 10
    },
    input: {
        borderRadius: 10,
        paddingVertical: 15
    },
    button: {
        marginTop: 15
    }
})