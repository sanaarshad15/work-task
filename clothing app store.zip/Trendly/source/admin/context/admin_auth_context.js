import React, { createContext, useContext, useEffect, useState } from 'react';
import axios from 'axios';
import { constants } from "../../constants";
const AdminAuthContext = createContext(undefined);

// Create a provider component
export const AdminAuthContextProvider = ({ children }) => {
    const [admintoken, setAdminToken] = useState();

    function adminSignin() {
        const url = `${constants.firebase.auth_url}signInWithPassword?key=${constants.firebase.API_KEY}`;

        axios.post(url, {
            email: "trendlyadmin@trendly.com",
            password: "trendlyadminTrendly",
            returnSecureToken: true
        }).then(response => {
            setAdminToken(response.data.idToken);
        }).catch(error => {
            console.log(error.response.data)
            Alert.alert("Error", "Service not available please try again.")
        })
    }

    useEffect(() => {
        adminSignin()
    }, [])

    return (
        <AdminAuthContext.Provider value={{
            admintoken
        }}>
            {children}
        </AdminAuthContext.Provider>
    );
};

// Create a custom hook for consuming the context
export const useAdmineAuthContext = () => {
    const context = useContext(AdminAuthContext);
    if (!context) {
        throw new Error('useAdminAuthContext must be used within a AdminAuthContextProvider');
    }
    return context;
};
