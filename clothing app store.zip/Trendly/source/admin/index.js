import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { ActivityIndicator, Alert, View, StyleSheet } from 'react-native';
import { useAdmineAuthContext } from './context/admin_auth_context';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';


import { ListCategory, AddCategory, } from "./categories";
import { ListItem, AddItem, } from "./items";
import { ListOrders, } from "./orders";
import { ListUsers, User } from "./users";

import {
    constants,
    Components,
} from './shared';

const Tab = createBottomTabNavigator()

const TabComp = ({ title, icon, focused }) => (
    <View style={[styles.tabCom]}>
        <Ionicons
            name={icon}
            size={16}
            color={focused ? 'tomato' : 'gray'}
        />
        <Components.Text.ButtonText
            text={title}
            textStyle={{ color: focused ? 'tomato' : 'gray', width: "100%" }}
        />
    </View>
)

function AdminTabNavigator() {
    return (
        <Tab.Navigator
            screenOptions={{
                headerShown: false,
                tabBarStyle: [styles.tabbar],
                tabBarShowLabel: false
            }}
        >


            <Tab.Screen name="category" component={ListCategory}
                options={{
                    tabBarIcon: ({ size, focused, color }) => (
                        <TabComp
                            title={"Category"}
                            icon={'list'}
                            focused={focused}
                        />
                    )
                }}
            />
            <Tab.Screen name="products" component={ListItem}
                options={{
                    tabBarIcon: ({ size, focused, color }) => (
                        <TabComp
                            title={"Products"}
                            icon={'pricetags'}
                            focused={focused}
                        />
                    )
                }}
            />
            <Tab.Screen name="orders" component={ListOrders}
                options={{
                    tabBarIcon: ({ size, focused, color }) => (
                        <TabComp
                            title={"Orders"}
                            icon={'cart'}
                            focused={focused}
                        />
                    )
                }}
            />
            <Tab.Screen name="users" component={ListUsers}
                options={{
                    tabBarIcon: ({ size, focused, color }) => (
                        <TabComp
                            title={"Users"}
                            icon={'people'}
                            focused={focused}
                        />
                    )
                }}
            />
        </Tab.Navigator>
    )
}


const Stack = createStackNavigator();

const AdminStack = () => {
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }} initialRouteName='tabs'>
            <Stack.Screen name='tabs' component={AdminTabNavigator} />
            <Stack.Screen name='addcategory' component={AddCategory} />
            <Stack.Screen name='additem' component={AddItem} />
            <Stack.Screen name='user' component={User} />
        </Stack.Navigator>
    )
}

export const AdminNavigator = () => {
    const { admintoken } = useAdmineAuthContext();
    

    if (admintoken) {
        return (
            <NavigationContainer>
                <AdminStack />
            </NavigationContainer>
        )
    } else {
        return (
            <View style={{ flex: 1, backgroundColor: constants.colors.background, justifyContent: "center", alignItems: "center" }}>
                <ActivityIndicator size="large" color={constants.colors.text} />
            </View>
        )
    }
}

const styles = StyleSheet.create({
    tabbar: {
        height: 75,
        backgroundColor: constants.colors.inputBackground,
        width: "100%",
    },
    tabCom: {
        marginTop: 15,
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
    }
})