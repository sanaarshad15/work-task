import React, { useState, useEffect } from "react";
import { View, StyleSheet, FlatList, Image, Alert } from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { Components, constants, useAdmineAuthContext, utils } from "../shared";
import { getCategories } from "../categories/function";


export default function ListItem({ navigation, route }) {

    const [loading, setLoading] = useState(true);
    const [categories, setCategories] = useState({});

    const [items, setItems] = useState({});
    const { admintoken } = useAdmineAuthContext();

    useEffect(() => {
        if (admintoken) {
            getCategories(admintoken, setCategories);
            utils.axiosRequests.read(admintoken, 'Products').then(response => {
                if (response.success) {
                    let tempProducts = {};
                    response.data.forEach((item, index) => {
                        if (item) {
                            tempProducts[item.id] = item
                        }
                    })
                    setItems(tempProducts);
                    setLoading(false)
                }
            }).catch(err => {
                console.log('Error getting products')
            })
        }
    }, [admintoken]);

    async function deleteProduct(productId) {
        try {
            const response = await utils.axiosRequests.remove(admintoken, `Products/${productId}`);
            if (response && response.success) {
                setItems((prevData) => {
                    const newData = { ...prevData }
                    delete newData[productId];
                    return newData
                })
            } else {
                Alert.alert("Error", 'Unable to delete product');
            }
        } catch (error) {
            console.log("Error deleting product", error);
            Alert.alert('Error', 'Unable to delete product')
        }
    }

    if (loading) {
        return <Components.Loader />
    }
    return (
        <View style={[styles.container]}>
            <View style={[styles.header]}>
                <Components.Buttons.TextButton
                    text={'Add'}
                    onPress={() => {
                        navigation.navigate('additem', {
                            setProducts: setItems,
                            id: items && Object.keys(items).length > 0
                                ? Math.max(...Object.keys(items).map(Number)) + 1
                                : 1,
                            item: undefined,
                            categories: categories
                        })
                    }}
                    buttonStyle={styles.addButton}
                />
            </View>
            <View style={[styles.body]}>
                <FlatList
                    data={Object.keys(items)}
                    keyExtractor={(_, index) => String(index)}
                    renderItem={({ item, index }) => {
                        const product = items[item];
                        if (product && product.id) {
                            return (
                                <View style={[styles.product]}>
                                    <Image
                                        source={constants.productImages[product.image].path}
                                        style={[styles.product_image]}
                                    />
                                    <View style={[styles.product_header]}>
                                        <Components.Text.SubHeading
                                            text={`${product.name}`}
                                        />
                                        <Ionicons
                                            name="trash-sharp"
                                            size={25}
                                            color={'red'}
                                            onPress={() => { deleteProduct(product.id) }}
                                        />
                                    </View>
                                    <View style={{ paddingHorizontal: 10 }}>
                                        <Components.Text.Body
                                            text={`PKR ${product.price}`}
                                            textStyle={styles.text}
                                        />
                                        <Components.Text.Body
                                            text={`${categories && categories[product.category] ? categories[product.category].name : 'Category unknown'}`}
                                            textStyle={styles.text}
                                        />
                                        <Components.Text.Body
                                            text={`${product.quantity} Units`}
                                            textStyle={styles.text}
                                        />
                                    </View>
                                    <View style={[styles.product_body]}>

                                        <Components.Text.Body
                                            text={`${product.description}`}
                                            textStyle={styles.description}
                                        />
                                        <View style={{ justifyContent: "center", alignItems: "center", marginTop: 10 }}>
                                            <Ionicons
                                                name="arrow-forward-circle"
                                                size={30}
                                                color={constants.colors.buttons}
                                                onPress={() => {
                                                    navigation.navigate('additem', {
                                                        setProducts: setItems,
                                                        id: product.id,
                                                        item: product,
                                                        categories: categories
                                                    })
                                                }}
                                            />
                                        </View>
                                    </View>
                                </View>
                            )
                        } else {
                            return null
                        }
                    }}

                />
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background
    },
    header: {
        flex: 0.15,
        justifyContent: "center",
        alignItems: "center"
    },
    addButton: {
        marginTop: 30,
        width: "90%",
    },
    body: {
        flex: 0.85,
        paddingHorizontal: 5,
    },
    product: {
        alignSelf: "center",
        width: "98%",
        paddingBottom: 10,
        backgroundColor: constants.colors.card,
        marginTop: 10,
        borderRadius: 5
    },
    product_image: {
        height: 160,
        width: '100%',
        resizeMode: "cover",
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
    },
    product_header: {
        paddingHorizontal: 10,
        marginTop: 5,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginTop: 5,
    },
    product_body: {
        paddingHorizontal: 10,
    },
    text: {
        marginTop: 5,
    },
    description: {
        marginTop: 5,
        fontSize: 11,
        fontWeight: 400
    }

})