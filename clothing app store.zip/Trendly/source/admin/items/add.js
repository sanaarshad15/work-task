import React, { useEffect, useRef, useState } from "react";
import { View, StyleSheet, Alert, Image, KeyboardAvoidingView, TouchableWithoutFeedback, Keyboard, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Picker } from '@react-native-picker/picker';

import {
    Components, constants,
    utils,
    useAdmineAuthContext
} from "../shared";
import { FlatList } from "react-native-gesture-handler";


export default function AddItem({ navigation, route }) {
    const { admintoken } = useAdmineAuthContext();
    const [loading, setLoading] = useState(false);

    const [name, setName] = useState();
    const nameRef = useRef(null);
    const [description, setDescription] = useState();
    const descriptionRef = useRef(null);
    const [price, setPrice] = useState();
    const priceRef = useRef(null)
    const [quantity, setQuantity] = useState(0);
    const quantityRef = useRef(null)
    const [category, setCategory] = useState();
    const [image, setImage] = useState();
    const id = route.params.id

    useEffect(() => {
        if (route.params.item) {
            setName(route.params.item.name);
            setDescription(route.params.item.description);
            setPrice(route.params.item.price);
            setCategory(route.params.item.category);
            setImage(route.params.item.image);
            setQuantity(route.params.item.quantity);
        } else {
            setCategory(Object.keys(route.params.categories)[0])
        }
    }, [route.params.item]);


    async function add() {
        setLoading(true);
        try {
            if (name !== undefined && name.length > 0) {
                if (description !== undefined && description.length > 0) {
                    if (price !== undefined && price > 0) {
                        if (image !== undefined) {
                            if (category !== undefined) {
                                if (quantity >= 0) {
                                    const data = {
                                        name: name,
                                        description: description,
                                        price: price,
                                        image: `${image}`,
                                        category: category,
                                        id: id,
                                        quantity: quantity,
                                    }
                                    let response;
                                    if (route.params.item) {
                                        response = await utils.axiosRequests.update(admintoken, `Products/${id}`, data)
                                    } else {
                                        response = await utils.axiosRequests.create(admintoken, `Products/${id}`, data)
                                    }
                                    if (response && response.success) {
                                        Alert.alert('Success', `Product ${route.params.item !== undefined ? 'Updated' : 'Added'}!`);
                                        route.params.setProducts((prevData) => ({
                                            ...prevData,
                                            [data.id]: data
                                        }))
                                        navigation.goBack();
                                        setLoading(false);
                                    } else {
                                        Alert.alert('Error', ` Unable to ${route.params.item !== undefined ? 'update' : 'add'} product`)
                                    }
                                } else {
                                    Alert.alert('Error', 'Please enter a valid quanitity');
                                }
                            } else {
                                Alert.alert("Error", "Please select a category")
                            }
                        } else {
                            Alert.alert("Error", "Please select an image")
                        }
                    } else {
                        Alert.alert("Error", "Please enter a valid price")
                    }
                } else {
                    Alert.alert("Error", "Please enter a valid description")
                }
            } else {
                Alert.alert("Error", "Please enter a valid name")
            }
        } catch (error) {
            console.error('Error adding/editing item:', error);
            Alert.alert("Error", "Unable to access database, Please try again.");
        } finally {
            setLoading(false)
        }
    }

    if (loading) {
        return <Components.Loader />
    }
    return (
        <TouchableWithoutFeedback style={{ flex: 1 }}
            onPress={() => { Keyboard.dismiss() }}
        >
            <View style={[styles.container]}>
                <KeyboardAvoidingView style={{ flex: 1 }}>

                    <View style={[styles.header]}>
                        <Components.Buttons.IconButton
                            Icon={<Ionicons
                                name="arrow-back-outline"
                                size={16}
                                color={constants.colors.buttonText}
                            />}
                            onPress={() => {
                                nameRef.current.clear();
                                setName();
                                navigation.goBack()
                            }}
                        />
                        <Components.Text.Heading
                            text={route.params.item !== undefined ? "Edit Product" : "Add Product"}
                        />
                        <View />
                    </View>
                    <View style={[styles.body]}>
                        <Components.Inputs.Input
                            onChangeText={setName}
                            ref={nameRef}
                            style={styles.input}
                            placeholder={'Product name'}
                            value={name}
                        />
                        <Components.Inputs.Input
                            onChangeText={setDescription}
                            ref={descriptionRef}
                            style={styles.input}
                            placeholder={'Product description'}
                            value={description}
                        />
                        <Components.Inputs.Input
                            onChangeText={setPrice}
                            ref={priceRef}
                            style={styles.input}
                            placeholder={'Product price'}
                            value={price}
                            inputMode='numeric'
                        />
                        <Components.Inputs.Input
                            onChangeText={setQuantity}
                            ref={quantityRef}
                            style={styles.input}
                            placeholder={'Product Quantity'}
                            value={quantity}
                            inputMode='numeric'
                        />
                        <View>
                            <FlatList
                                data={Object.keys(constants.productImages)}
                                keyExtractor={(item, index) => String(index)}
                                renderItem={({ item, index }) => {
                                    if (image === item) {
                                        return (
                                            <Image source={constants.productImages[item].path} style={[styles.selectedImage]} />
                                        )
                                    } else {
                                        return (
                                            <TouchableOpacity onPress={() => { setImage(item) }} style={{ width: "200", marginHorizontal: 10 }}>
                                                <Image source={constants.productImages[item].path} style={[styles.unSelectedImage]} />
                                            </TouchableOpacity>
                                        )
                                    }
                                }}
                                showsHorizontalScrollIndicator={false}
                                horizontal
                            />
                        </View>
                        <View>
                            <Picker
                                selectedValue={category}
                                onValueChange={(itemValue, itemIndex) => { setCategory(itemValue) }}
                                style={styles.picker}
                            >
                                {
                                    Object.values(route.params.categories).map((item, index) => (
                                        <Picker.Item label={item.name} value={item.id} key={index} />
                                    ))
                                }
                            </Picker>
                        </View>
                        <Components.Buttons.TextButton
                            text={route.params.item !== undefined ? 'Update' : 'Add'}
                            onPress={add}
                            buttonStyle={styles.button}
                        />
                    </View>
                </KeyboardAvoidingView>
            </View>
        </TouchableWithoutFeedback>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background
    },
    header: {
        flex: 0.15,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingHorizontal: 10,
        paddingTop: 10
    },
    body: {
        flex: 0.85,
        paddingHorizontal: 20,
        paddingTop: 10
    },
    input: {
        borderRadius: 10,
        paddingVertical: 15,
        marginTop: 5,
    },
    selectedImage: {
        height: 200,
        width: 200,
        marginTop: 10,
        resizeMode: "cover",
        borderWidth: 1,
        borderColor: constants.colors.buttons,
        alignSelf: "center"
    },
    unSelectedImage: {
        height: 200,
        width: 200,
        marginTop: 10,
        resizeMode: "cover",
        borderWidth: 1,
        borderColor: constants.colors.border,
        marginHorizontal: 10,
        alignSelf: "center"
    },
    button: {
        marginTop: 15
    }
})