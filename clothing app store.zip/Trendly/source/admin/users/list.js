import React, { useEffect, useState } from "react";
import { View, StyleSheet, SafeAreaView, FlatList, Platform } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Components, constants, useAdmineAuthContext, utils, } from "../shared";


export default function ListUsers({ navigation, route }) {
    const { admintoken } = useAdmineAuthContext()
    const [users, setUsers] = useState({});

    async function getAllUsers() {
        try {
            const users = await utils.axiosRequests.read(admintoken, 'Users');
            if (users.success) {
                let tempUsers = {}
                Object.keys(users.data).forEach((item, index) => {
                    if (users.data[item].Profile) {
                        tempUsers[item] = users.data[item].Profile
                    }
                })
                setUsers(tempUsers)
            }
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        getAllUsers();
    }, []);

    return (
        <View style={[styles.container]}>
            <SafeAreaView style={{
                flex: 1,
                paddingTop: Platform.OS === "ios" ? 0 : 30,


            }}>
                <FlatList
                    data={Object.keys(users)}
                    keyExtractor={(item, index) => item}
                    renderItem={({ item, index }) => {
                        return (
                            <View style={[styles.user]}>
                                <Components.Text.ButtonText
                                    text={`${users[item].firstName} ${users[item].lastName}`}
                                    textStyle={styles.username}
                                />
                                <Ionicons
                                    name="arrow-forward-circle-sharp"
                                    size={20}
                                    color={constants.colors.buttons}
                                    onPress={() => {
                                        navigation.navigate('user', { id: item })
                                    }}
                                />
                            </View>
                        )
                    }}

                />
            </SafeAreaView>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background,
        paddingHorizontal: 10
    },
    user: {
        backgroundColor: constants.colors.card,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingVertical: 10,
        paddingHorizontal: 15,
        borderRadius: 5
    },
    username: {
        fontSize: 13,
        fontWeight: 600,
        color: "#000"
    },
    profileButton: {

    }
})