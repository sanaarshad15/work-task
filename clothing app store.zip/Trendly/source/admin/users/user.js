import React, { useEffect, useState } from "react";
import axios from "axios";
import { View, StyleSheet, Alert, Platform, ScrollView } from "react-native";
import { Components, constants, useAdmineAuthContext, utils } from "../shared";
import { Ionicons } from "@expo/vector-icons";


export default function User({ navigation, route }) {
    const { admintoken } = useAdmineAuthContext()
    const [user, setUser] = useState();
    const [order, setOrders] = useState({});

    async function getUserProfile(userId) {
        try {
            const response = await utils.axiosRequests.read(admintoken, `Users/${userId}/Profile`);
            if (response.success) {
                setUser(response.data)
            }
        } catch (error) {
            console.error('Error fetching user profile:', error.code, error.message);
        }
    }

    async function getUserOrders(userId) {
        try {
            const params = {
                auth: admintoken,
                orderBy: '"userId"',
                equalTo: `"${userId}"`
            };
            const response = await axios.get(`${constants.firebase.db}Orders.json`, { params });
            if (response.data) {
                let tempOrders = {}
                Object.keys(response.data).forEach((item, index) => {
                    tempOrders[item] = { ...response.data[item], id: item }
                });
                setOrders(tempOrders)
            }
        } catch (error) {
            console.error('Error fetching orders:', error.code, error.message);
        }
    }

    async function cancel(orderId) {
        const update = {
            updatedAt: new Date().getTime(),
            status: "Cancelled",
        }
        try {
            const response = await utils.axiosRequests.update(admintoken, `Orders/${orderId}`, update)
            if (response.success) {
                Alert.alert("Success", `Order #${orderId} moved to Cancelled`)
                setOrders((prevData) => ({
                    ...prevData,
                    [orderId]: { ...order[orderId], ...update }
                }));
                try {
                    const productsInOrder = order[orderId].products
                    for (const item of productsInOrder) {
                        const path = `Products/${item.id}/quantity`;
                        const response = await utils.axiosRequests.read(admintoken, path);
                        if (response.success) {
                            const updatequantity = await utils.axiosRequests.update(admintoken, `Products/${item.id}`, {
                                quantity: Number(response.data) + Number(item.quantity)
                            })
                        }
                    }
                } catch (error) {
                    console.log('Error updating quantity of product', error);
                }
                Alert.alert("Success", `Order #${orderId} Cancelled Successfully`);
            } else {
                Alert.alert("Error", `Unable to move Order #${orderId} to Cancelled`);
            }
        } catch (error) {
            console.error('Error updating order status admin:', error);
            Alert.alert("Error", `Unable to move Order #${orderId} to Cancelled`);
        }
    }

    async function updateStatus(orderId, newStatus) {
        const update = {
            updatedAt: new Date().getTime(),
            status: newStatus,
        }
        try {
            const response = await utils.axiosRequests.update(admintoken, `Orders/${orderId}`, update)
            if (response.success) {
                Alert.alert("Success", `Order #${orderId} moved to ${newStatus}`)
                setOrders((prevData) => ({
                    ...prevData,
                    [orderId]: { ...order[orderId], ...update }
                }))
            } else {
                Alert.alert('Error', 'Unable to update order')
            }
        } catch (error) {
            console.error('Error updating order status admin:', error);
            Alert.alert("Error", `Unable to move Order #${orderId} to ${newStatus}`)
        }
    }

    function RenderActionButton({ orderId, status }) {
        if (status === 'Pending') {
            return (
                <View style={[styles.action_container]}>
                    <Components.Buttons.TextButton
                        text={'Approve'}
                        textStyle={styles.action_button_text}
                        buttonStyle={styles.action_button}
                        onPress={() => { updateStatus(orderId, 'Approved') }}

                    />
                    <Components.Buttons.TextButton
                        text={'Cancel'}
                        textStyle={styles.action_button_text}
                        buttonStyle={styles.cancel_button}
                        onPress={() => { cancel(orderId) }}

                    />
                </View>
            )
        } else if (status === 'Approved') {
            return (
                <View style={[styles.action_container]}>
                    <Components.Buttons.TextButton
                        text={'Dispatch'}
                        textStyle={styles.action_button_text}
                        buttonStyle={styles.action_button}
                        onPress={() => { updateStatus(orderId, 'Dispatched') }}

                    />
                    <Components.Buttons.TextButton
                        text={'Cancel'}
                        textStyle={styles.action_button_text}
                        buttonStyle={styles.cancel_button}
                        onPress={() => { cancel(orderId) }}

                    />
                </View>
            )
        } else if (status === 'Dispatched') {
            return (
                <View style={[styles.action_container]}>
                    <Components.Buttons.TextButton
                        text={'Deliver'}
                        textStyle={styles.action_button_text}
                        buttonStyle={styles.action_button}
                        onPress={() => { updateStatus(orderId, 'Delivered') }}

                    />
                    <Components.Buttons.TextButton
                        text={'Cancel'}
                        textStyle={styles.action_button_text}
                        buttonStyle={styles.cancel_button}
                        onPress={() => { cancel(orderId) }}

                    />
                </View>
            )
        } else {
            return null
        }
    }


    useEffect(() => {
        getUserProfile(route.params.id);
        getUserOrders(route.params.id);
    }, [route.params.id])



    const InfoComp = ({ title, value }) => {
        return (
            <View style={[styles.info_container]}>
                <Components.Text.SubHeading
                    text={title}
                    textStyle={styles.info_heading}
                />
                <View style={[styles.info_text_contaienr]}>
                    <Components.Text.Body
                        text={value}
                        textStyle={styles.info_text}
                    />
                </View>
            </View>
        )
    }


    return (
        <View style={[styles.container]}>
            <View style={[styles.header]}>
                <Ionicons
                    name="arrow-back-outline"
                    size={20}
                    color={constants.colors.buttons}
                    onPress={() => { navigation.goBack() }}
                    style={{ marginTop: Platform.OS === "ios" ? 25 : 10, }}
                />
                <Components.Text.Heading
                    text={'Profile'}
                    textStyle={{ marginTop: Platform.OS === "ios" ? 25 : 10, color: '#000' }}
                />
                <View />
            </View>
            <View style={[styles.body]}>
                <ScrollView style={{ flex: 1, flexGrow: 1 }} showsVerticalScrollIndicator={false}>
                    {
                        user ?
                            <>
                                <InfoComp title={'First Name'} value={user.firstName} />
                                <InfoComp title={'Last Name'} value={user.lastName} />
                                <InfoComp title={'Age'} value={user.age} />
                                <InfoComp title={'Email'} value={user.email} />
                                <InfoComp title={'Phone'} value={user.phone} />
                                <InfoComp title={'Address'} value={user.address} />
                                <Components.Text.Body
                                    text={'Orders'}
                                    textStyle={styles.orderHeading}
                                />
                                <View style={[styles.order_container]}>

                                    {
                                        Object.values(order).map((order, index) => {
                                            return (
                                                <View style={[styles.order_container]} key={index}>
                                                    <View style={[styles.order_header]}>
                                                        <Components.Text.SubHeading
                                                            text={`Order id #${order.id}`}
                                                            textStyle={{ color: '#000' }}
                                                        />
                                                        <Components.Text.SubHeading
                                                            text={order.status}
                                                            textStyle={{ color: 'tomato' }}
                                                        />
                                                    </View>
                                                    <View style={{ marginTop: 10 }}>
                                                        {
                                                            order.products.map((item, index) => {
                                                                return (
                                                                    <View style={[styles.product_container]} key={String(index)}>
                                                                        <Components.Text.Body
                                                                            text={item.name}
                                                                            textStyle={styles.product_name}
                                                                        />
                                                                        <Components.Text.Body
                                                                            text={`${item.quantity}`}
                                                                            textStyle={styles.product_quantity}
                                                                        />
                                                                        <Components.Text.Body
                                                                            text={`PKR ${item.total}`}
                                                                            textStyle={styles.product_price}
                                                                        />
                                                                    </View>
                                                                )
                                                            })
                                                        }
                                                    </View>
                                                    <View style={[styles.amount_Container]}>
                                                        <View style={[styles.total_view]}>
                                                            <Components.Text.SubHeading
                                                                text={'Sub-total'}
                                                                textStyle={styles.amount_title}
                                                            />
                                                            <Components.Text.SubHeading
                                                                text={`PKR ${order.subTotal}`}
                                                                textStyle={styles.amount_value}
                                                            />
                                                        </View>
                                                        <View style={[styles.total_view]}>
                                                            <Components.Text.SubHeading
                                                                text={'Tax (17% GST)'}
                                                                textStyle={styles.amount_title}
                                                            />
                                                            <Components.Text.SubHeading
                                                                text={`PKR ${order.tax}`}
                                                                textStyle={styles.amount_value}
                                                            />
                                                        </View>
                                                        <View style={[styles.total_view]}>
                                                            <Components.Text.SubHeading
                                                                text={'Total (incl. tax & delivery fee ) '}
                                                                textStyle={[styles.amount_title, { color: '#000' }]}
                                                            />
                                                            <Components.Text.SubHeading
                                                                text={`PKR ${order.total}`}
                                                                textStyle={styles.amount_value}
                                                            />
                                                        </View>
                                                    </View>
                                                    <View style={[styles.date_cotnainer]}>
                                                        <Components.Text.Body
                                                            text={`Placed at: ${String(new Date(order.placedAt))}`}
                                                            textStyle={styles.date_text}
                                                        />
                                                        {
                                                            order.status === 'Delivered' ?
                                                                <Components.Text.Body
                                                                    text={`Delivered at: ${String(new Date(order.updatedAt))}`}
                                                                    textStyle={styles.date_text}
                                                                /> :
                                                                null
                                                        }
                                                    </View>
                                                    <View>
                                                        <RenderActionButton
                                                            orderId={order.id}
                                                            status={order.status}
                                                        />
                                                    </View>
                                                </View>
                                            )
                                        })
                                    }
                                </View>
                            </> :
                            null
                    }
                </ScrollView>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background
    },
    header: {
        flex: Platform.OS === "ios" ? 0.15 : 0.1,
        paddingHorizontal: 20,
        backgroundColor: constants.colors.card,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center"
    },
    body: {
        flex: Platform.OS === "ios" ? 0.85 : 0.9,
        paddingHorizontal: 10,
        paddingTop: 10,
        paddingBottom: 20,
    },
    info_container: {
        marginTop: 10
    },
    info_heading: {
        color: constants.colors.text
    },
    info_text_contaienr: {
        marginTop: 5,
        backgroundColor: constants.colors.card,
        paddingVertical: 10,
        paddingHorizontal: 5,
        borderRadius: 10,
        width: "100%",
    },
    info_text: {
        fontSize: 15,
        color: constants.colors.text
    },
    orderHeading: {
        marginTop: 10,
        fontWeight: "600",
        color: '#000',
        fontSize: 16
    },
    order_container: {
        backgroundColor: constants.colors.card,
        paddingVertical: 5,
        paddingHorizontal: 10,
        borderRadius: 5,
        marginTop: 5,
    },
    order_header: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    product_container: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    product_name: {
        fontSize: 12,
        fontWeight: '400',
        color: '#000'
    },
    product_quantity: {
        fontSize: 12,
        fontWeight: '400',
        color: '#000'
    },
    product_price: {
        fontSize: 12,
        fontWeight: '400',
        color: 'tomato'
    },
    amount_Container: {
        marginTop: 10,
        paddingTop: 10,
        borderTopWidth: 2,
        borderColor: constants.colors.border
    },
    total_view: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginVertical: 2
    },
    amount_title: {
        fontSize: 11,
    },
    amount_value: {
        fontSize: 11,
        color: 'tomato'
    },
    date_cotnainer: {
        paddingVertical: 5
    },
    date_text: {
        color: '#000',
        marginTop: 10
    },
    action_container: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginTop: 10,
        paddingBottom: 10
    },
    action_button: {
        width: '60%',
        marginHorizontal: 5
    },
    cancel_button: {
        width: '35%',
        marginHorizontal: 5,
        backgroundColor: 'tomato'
    },
    action_button_text: {
        fontSize: 12,
        fontWeight: 600
    }
})