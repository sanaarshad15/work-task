import React, { useEffect, useState } from "react";
import { View, StyleSheet, SafeAreaView, FlatList, Platform, Alert, TouchableOpacity, } from "react-native";
import { Components, constants, useAdmineAuthContext, utils } from "../shared";


export default function ListOrders({ navigation, route }) {

    const { admintoken } = useAdmineAuthContext();
    const [orders, setOrders] = useState({});
    const [loading, setLoading] = useState();
    const [selected, setSelected] = useState('Pending');

    useEffect(() => {
        utils.axiosRequests.read(admintoken, 'Orders').then(response => {
            let tempOrders = {}
            if (response.success && response.data) {
                Object.keys(response.data).forEach((item, index) => {
                    tempOrders[item] = { ...response.data[item], id: item }
                })
                setOrders(tempOrders)
            }
        }).catch(err => {
            console.log(err)
        })
    }, [])

    async function cancel(orderId) {
        const update = {
            updatedAt: new Date().getTime(),
            status: "Cancelled",
        }
        try {
            const response = await utils.axiosRequests.update(admintoken, `Orders/${orderId}`, update)
            if (response.success) {
                Alert.alert("Success", `Order #${orderId} moved to Cancelled`)
                setOrders((prevData) => ({
                    ...prevData,
                    [orderId]: { ...orders[orderId], ...update }
                }));
                try {
                    const productsInOrder = orders[orderId].products
                    for (const item of productsInOrder) {
                        const path = `Products/${item.id}/quantity`;
                        const response = await utils.axiosRequests.read(admintoken, path);
                        if (response.success) {
                            const updatequantity = await utils.axiosRequests.update(admintoken, `Products/${item.id}`, {
                                quantity: Number(response.data) + Number(item.quantity)
                            })
                        }
                    }
                } catch (error) {
                    console.log('Error updating quantity of product', error);
                }
                Alert.alert("Success", `Order #${orderId} Cancelled Successfully`);
            } else {
                Alert.alert("Error", `Unable to move Order #${orderId} to Cancelled`);
            }
        } catch (error) {
            console.error('Error updating order status admin:', error);
            Alert.alert("Error", `Unable to move Order #${orderId} to Cancelled`);
        }
    }

    async function updateStatus(orderId, newStatus) {
        const update = {
            updatedAt: new Date().getTime(),
            status: newStatus,
        }
        try {
            const response = await utils.axiosRequests.update(admintoken, `Orders/${orderId}`, update)
            if (response.success) {
                Alert.alert("Success", `Order #${orderId} moved to ${newStatus}`)
                setOrders((prevData) => ({
                    ...prevData,
                    [orderId]: { ...orders[orderId], ...update }
                }))
            } else {
                Alert.alert('Error', 'Unable to update order')
            }
        } catch (error) {
            console.error('Error updating order status admin:', error);
            Alert.alert("Error", `Unable to move Order #${orderId} to ${newStatus}`)
        }
    }



    function RenderActionButton({ orderId, status }) {
        if (status === 'Pending') {
            return (
                <View style={[styles.action_container]}>
                    <Components.Buttons.TextButton
                        text={'Approve'}
                        textStyle={styles.action_button_text}
                        buttonStyle={styles.action_button}
                        onPress={() => { updateStatus(orderId, 'Approved') }}

                    />
                    <Components.Buttons.TextButton
                        text={'Cancel'}
                        textStyle={styles.action_button_text}
                        buttonStyle={styles.cancel_button}
                        onPress={() => { cancel(orderId) }}

                    />
                </View>
            )
        } else if (status === 'Approved') {
            return (
                <View style={[styles.action_container]}>
                    <Components.Buttons.TextButton
                        text={'Dispatch'}
                        textStyle={styles.action_button_text}
                        buttonStyle={styles.action_button}
                        onPress={() => { updateStatus(orderId, 'Dispatched') }}

                    />
                    <Components.Buttons.TextButton
                        text={'Cancel'}
                        textStyle={styles.action_button_text}
                        buttonStyle={styles.cancel_button}
                        onPress={() => { cancel(orderId) }}

                    />
                </View>
            )
        } else if (status === 'Dispatched') {
            return (
                <View style={[styles.action_container]}>
                    <Components.Buttons.TextButton
                        text={'Deliver'}
                        textStyle={styles.action_button_text}
                        buttonStyle={styles.action_button}
                        onPress={() => { updateStatus(orderId, 'Delivered') }}

                    />
                    <Components.Buttons.TextButton
                        text={'Cancel'}
                        textStyle={styles.action_button_text}
                        buttonStyle={styles.cancel_button}
                        onPress={() => { cancel(orderId) }}

                    />
                </View>
            )
        } else {
            return null
        }
    }


    return (
        <View style={[styles.container]}>
            <SafeAreaView style={{ flex: 1, paddingTop: Platform.OS === "ios" ? 0 : 30 }}>
                <View style={{ flex: 0.15, backgroundColor: constants.colors.card }}>
                    <FlatList
                        data={['Pending', 'Approved', 'Dispatched', 'Delivered', 'Cancelled']}
                        keyExtractor={(item, index) => String(index)}
                        numColumns={3}
                        renderItem={({ item, index }) => {
                            return (
                                <Components.Buttons.TextButton
                                    text={item}
                                    textStyle={selected !== item ? styles.button_text : [styles.button_text, { color: constants.colors.buttonText }]}
                                    buttonStyle={selected !== item ? styles.type_button : [styles.type_button, { backgroundColor: constants.colors.buttons }]}
                                    onPress={() => { setSelected(item) }}
                                />
                            )
                        }}

                    />
                </View>
                <View style={{ flex: 0.85 }}>
                    <FlatList
                        showsVerticalScrollIndicator={false}
                        data={
                            Object.keys(orders).map((item, index) => {
                                if (orders[item].status === selected) {
                                    return item
                                }
                            })
                        }
                        keyExtractor={(item, index) => String(index)}
                        renderItem={({ item, index }) => {
                            const order = orders[item];
                            if (order) {
                                return (
                                    <View style={[styles.order_container]}>
                                        <View style={[styles.order_header]}>
                                            <Components.Text.SubHeading
                                                text={`Order id #${order.id}`}
                                                textStyle={{ color: '#000' }}
                                            />
                                            <Components.Text.SubHeading
                                                text={order.status}
                                                textStyle={{ color: 'tomato' }}
                                            />
                                        </View>
                                        <View style={[styles.user_info]}>
                                            <TouchableOpacity onPress={() => {
                                                navigation.navigate('user', { id: order.userId })
                                            }}>
                                                <Components.Text.Body
                                                    text={`UserId: ${order.userId}`}
                                                    textStyle={[styles.info_text, { color: constants.colors.buttons, marginBottom: 10 }]}
                                                />
                                            </TouchableOpacity>
                                            <Components.Text.Body
                                                text={`Address: ${order.address}`}
                                                textStyle={styles.info_text}
                                            />
                                            <Components.Text.Body
                                                text={`Payment: Cash on Delivery`}
                                                textStyle={styles.info_text}
                                            />
                                        </View>
                                        <View>
                                            <Components.Text.SubHeading
                                                text={`Order Details`}
                                                textStyle={{ color: '#000', paddingBottom: 5 }}

                                            />
                                            {
                                                order.products.map((item, index) => {
                                                    return (
                                                        <View style={[styles.product_container]} key={String(index)}>
                                                            <Components.Text.Body
                                                                text={item.name}
                                                                textStyle={styles.product_name}
                                                            />
                                                            <Components.Text.Body
                                                                text={`${item.quantity}`}
                                                                textStyle={styles.product_quantity}
                                                            />
                                                            <Components.Text.Body
                                                                text={`PKR ${item.total}`}
                                                                textStyle={styles.product_price}
                                                            />
                                                        </View>
                                                    )
                                                })
                                            }
                                        </View>
                                        <View style={[styles.amount_Container]}>
                                            <View style={[styles.total_view]}>
                                                <Components.Text.SubHeading
                                                    text={'Sub-total'}
                                                    textStyle={styles.amount_title}
                                                />
                                                <Components.Text.SubHeading
                                                    text={`PKR ${order.subTotal}`}
                                                    textStyle={styles.amount_value}
                                                />
                                            </View>
                                            <View style={[styles.total_view]}>
                                                <Components.Text.SubHeading
                                                    text={'Tax (17% GST)'}
                                                    textStyle={styles.amount_title}
                                                />
                                                <Components.Text.SubHeading
                                                    text={`PKR ${order.tax}`}
                                                    textStyle={styles.amount_value}
                                                />
                                            </View>
                                            <View style={[styles.total_view]}>
                                                <Components.Text.SubHeading
                                                    text={'Total (incl. tax & delivery fee ) '}
                                                    textStyle={[styles.amount_title, { color: '#000' }]}
                                                />
                                                <Components.Text.SubHeading
                                                    text={`PKR ${order.total}`}
                                                    textStyle={styles.amount_value}
                                                />
                                            </View>
                                        </View>
                                        <View style={[styles.date_cotnainer]}>
                                            <Components.Text.Body
                                                text={`Placed at: ${String(new Date(order.placedAt))}`}
                                                textStyle={styles.date_text}
                                            />
                                            {
                                                order.status === 'Delivered' ?
                                                    <Components.Text.Body
                                                        text={`Delivered at: ${String(new Date(order.updatedAt))}`}
                                                        textStyle={styles.date_text}
                                                    /> :
                                                    null
                                            }
                                        </View>
                                        <View>
                                            <RenderActionButton
                                                orderId={item}
                                                status={order.status}
                                            />
                                        </View>
                                    </View>
                                )
                            } else {
                                return null
                            }
                        }}
                    />
                </View>
            </SafeAreaView>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background
    },
    type_button: {
        marginHorizontal: 5,
        width: 120,
        backgroundColor: constants.colors.background,
        borderColor: constants.colors.buttons,
        borderWidth: 1,
        height: 40,
        marginTop: 5
    },
    button_text: {
        fontSize: 10,
        fontWeight: 500,
        color: constants.colors.buttons
    },
    order_container: {
        backgroundColor: constants.colors.card,
        paddingVertical: 10,
        paddingHorizontal: 10,
        borderRadius: 5,
        marginTop: 15
    },
    order_header: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    user_info: {
        marginVertical: 10
    },
    info_text: {
        marginVertical: 1
    },
    product_container: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    product_name: {
        fontSize: 12,
        fontWeight: '400',
        color: '#000'
    },
    product_quantity: {
        fontSize: 12,
        fontWeight: '400',
        color: '#000'
    },
    product_price: {
        fontSize: 12,
        fontWeight: '400',
        color: 'tomato'
    },
    amount_Container: {
        marginTop: 10,
        paddingTop: 10,
        borderTopWidth: 2,
        borderColor: constants.colors.border
    },
    total_view: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginVertical: 2
    },
    amount_title: {
        fontSize: 11,
    },
    amount_value: {
        fontSize: 11,
        color: 'tomato'
    },
    date_cotnainer: {
        paddingVertical: 5
    },
    date_text: {
        color: '#000',
        marginTop: 10
    },
    action_container: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginTop: 10,
        paddingBottom: 10
    },
    action_button: {
        width: '60%',
        marginHorizontal: 5
    },
    cancel_button: {
        width: '35%',
        marginHorizontal: 5,
        backgroundColor: 'tomato'
    },
    action_button_text: {
        fontSize: 12,
        fontWeight: 600
    }
})