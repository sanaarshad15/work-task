import React, { createContext, useContext, useState, } from 'react';

const AuthContext = createContext(undefined);

// Create a provider component
export const AuthContextProvider = ({ children }) => {
    const [userProfile, setUserProfile] = useState(null);

    // Function to update user profile
    function updateUser(profile) {
        setUserProfile(profile);
    }


    return (
        <AuthContext.Provider value={{
            user: userProfile,
            updateUser,
        }}>
            {children}
        </AuthContext.Provider>
    );
};

// Create a custom hook for consuming the context
export const useAuthContext = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuthContext must be used within a AuthContextProvider');
    }
    return context;
};
