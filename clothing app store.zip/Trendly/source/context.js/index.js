import { AuthContextProvider, useAuthContext } from "./auth";
import { CartContextProvider, useCartContext } from "./cart";
import { ProductContextProvider,useProductContext } from "./products";


function CombineContextProvider({ children }) {
    return (
        <AuthContextProvider>
            <ProductContextProvider>
                <CartContextProvider>
                    {children}
                </CartContextProvider>
            </ProductContextProvider>
        </AuthContextProvider>
    )
}

export {
    CombineContextProvider,
    useAuthContext,
    useCartContext,
    useProductContext
}