// MyContext.tsx
import React, {
    createContext, useContext, useState, useEffect,
} from 'react';
import { useAuthContext } from './auth';
import { utils } from '../utils';


const ProductContext = createContext(undefined);
// Create a provider component
export const ProductContextProvider = ({ children }) => {


    const [categories, setCategories] = useState({});
    const [products, setProducts] = useState({});

    const { user } = useAuthContext()

    async function getCategories() {
        if (user.auth) {
            try {
                const response = await utils.axiosRequests.read(user.token, `Categories`);
                let tempCategories = {}
                if (response.success && response.data) {
                    response.data.forEach((item, index) => {
                        if (item) {
                            tempCategories[item.id] = item
                        }
                    })
                }
                setCategories(tempCategories)
            } catch (error) {
                console.error('Error fetching categories:', error);
                setCategories({})
            }
        } else {
            setCategories({})
        }
    }

    async function getProducts() {
        if (user.auth) {
            try {
                const response = await utils.axiosRequests.read(user.token, `Products`);
                let tempProducts = {}
                if (response.success && response.data) {
                    response.data.forEach((item, index) => {
                        if (item) {
                            tempProducts[item.id] = item
                        }
                    })
                }
                setProducts(tempProducts)
            } catch (error) {
                console.error('Error fetching products:', error);
                setProducts({})
            }
        } else {
            setProducts({})
        }
    }

    useEffect(() => {
        getProducts();
        getCategories()
        const intervalid = setInterval(() => {

        }, 10000)
        return (() => {
            clearInterval(intervalid);
        })
    }, [user]);


    return (
        <ProductContext.Provider value={{ categories, products }}>
            {children}
        </ProductContext.Provider>
    );
};


// Create a custom hook for consuming the context
export const useProductContext = () => {
    const context = useContext(ProductContext);
    if (!context) {
        throw new Error('useProductContext must be used within a ProductContextProvider');
    }
    return context;
};
