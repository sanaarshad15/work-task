// MyContext.tsx
import React, {
    createContext, useContext, useState, useEffect
} from 'react';
import { useProductContext } from './products';

const CartContext = createContext(undefined);
// Create a provider component
export const CartContextProvider = ({ children }) => {

    const [cartContent, setCartContent] = useState({});

    function updateCart(data) {
        setCartContent(data);
    }

    const { products } = useProductContext()
    useEffect(() => {
        if (products && Object.keys(cartContent).length > 0) {
            const updatedCartContent = { ...cartContent };
            let hasChanges = false;

            Object.keys(cartContent).forEach((productId) => {
                if (!products[productId] || products[productId].quantity === 0) {
                    // Product no longer exists; remove it from cart
                    delete updatedCartContent[productId];
                    hasChanges = true;
                }
            });
            // If any changes were made, update the cart
            if (hasChanges) {
                setCartContent(updatedCartContent);
            }
        }
    }, [products, cartContent]);

    return (
        <CartContext.Provider value={{cartContent, updateCart}}>
            {children}
        </CartContext.Provider>
    );
};


// Create a custom hook for consuming the context
export const useCartContext = () => {
    const context = useContext(CartContext);
    if (!context) {
        throw new Error('useCartContext must be used within a CartContextProvider');
    }
    return context;
};
