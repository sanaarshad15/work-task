import React from "react";
import { Text, StyleSheet } from "react-native";
import { constants } from "@/source/constants";

export function Heading({ text, textStyle, ...props }) {
    return (
        <Text style={[styles.heading, textStyle]} {...props}>
            {text}
        </Text>
    );
}

export function SubHeading({ text, textStyle, ...props }) {
    return (
        <Text style={[styles.subHeading, textStyle]} {...props}>
            {text}
        </Text>
    );
}

export function Body({ text, textStyle, ...props }) {
    return (
        <Text style={[styles.body, textStyle]} {...props}>
            {text}
        </Text>
    );
}

export function ButtonText({ text, textStyle, ...props }) {
    return (
        <Text style={[styles.button, textStyle]} {...props}>
            {text}
        </Text>
    );
}


export const CustomText = {
    Heading,
    SubHeading,
    Body,
    ButtonText
}



const styles = StyleSheet.create({
    heading: {
        fontSize: 18,
        fontWeight: "700",
        color: constants.colors.text
    },
    subHeading: {
        fontSize: 15,
        fontWeight: "600",
        color: constants.colors.text
    },
    body: {
        fontSize: 13,
        fontWeight: "500",
        color: constants.colors.text
    },
    button: {
        fontSize: 14,
        fontWeight: "600",
        color: constants.colors.text
    }
})