import React, { forwardRef } from "react";
import { TextInput, StyleSheet, } from "react-native";
import { constants } from "../../constants";

export const Input = forwardRef((props, ref) => {
    const {
        style,
        placeholder,
        value,
        inputMode,
        ...resetProps
    } = props
    return (
        <TextInput
            ref={ref}
            placeholder={placeholder}
            style={[styles.input, props.style]}
            placeholderTextColor={"#00000090"}
            value={value}
            inputMode={inputMode}
            {...resetProps}
        />
    );
});


const styles = StyleSheet.create({
    input: {
        borderWidth: 1,
        borderColor: constants.colors.border,
        backgroundColor: constants.colors.inputBackground,
        color: constants.colors.inputText,
        fontSize: 14,
        paddingVertical: 5,
        paddingHorizontal: 10
    }
})