import React, { forwardRef } from "react";
import { TextInput, StyleSheet, View } from "react-native";
import { CustomText } from "../text";
import { constants } from "../../constants";


export const TitleInput = forwardRef((props, ref) => {
    const {
        containerStyle,
        title,
        titleStyle,
        placeholder,
        style,
        value,
        setText,
        inputMode,
        ...resetProps
    } = props

    return (
        <View style={[styles.container, containerStyle]}>
            <CustomText.SubHeading
                text={title}
                textStyle={[styles.title, titleStyle]}
            />
            <TextInput
                ref={ref}
                placeholder={placeholder}
                style={[styles.input, props.style]}
                placeholderTextColor={"#00000090"}
                inputMode={inputMode}
                onChangeText={setText}
                value={value}
                {...resetProps}
            />
        </View>
    );
});


const styles = StyleSheet.create({
    container: {
        alignItems: "flex-start",
        justifyContent: "flex-start"
    },
    title: {
        color: constants.colors.text
    },
    input: {
        borderWidth: 1,
        borderColor: constants.colors.border,
        backgroundColor: constants.colors.inputBackground,
        color: constants.colors.inputText,
        fontSize: 14,
        paddingVertical: 5,
        paddingHorizontal: 10
    }
})