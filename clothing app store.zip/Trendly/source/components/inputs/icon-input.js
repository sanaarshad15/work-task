import React, { forwardRef } from "react";
import { TextInput, StyleSheet, View } from "react-native";
import { CustomText } from "../text";
import { constants } from "../../constants";


export const IconInput = forwardRef(({
    containerStyle,
    title,
    titleStyle,
    IconButton,
    iconPosition,
    inputStyle,
    placeholder,
    value,
    setText,
    inputMode
}, ref) => {

    return (
        <View style={[styles.container, containerStyle]}>
            {
                title ?
                    <CustomText.Body
                        text={title}
                        textStyle={titleStyle}
                    /> :
                    null
            }
            <View style={[styles.input_container]}>
                {
                    iconPosition === "left" ?
                        <IconButton />
                        :
                        null
                }
                <TextInput
                    ref={ref}
                    placeholder={placeholder}
                    placeholderTextColor={"#00000090"}
                    style={[styles.input, inputStyle]}
                    onChangeText={setText}
                    value={value}
                    inputMode={inputMode}
                />
                {
                    iconPosition === "right" ?
                        <IconButton />
                        :
                        null
                }
            </View>
        </View>
    );
});


const styles = StyleSheet.create({
    container: {
        alignItems: "flex-start",
        justifyContent: "flex-start",
        width: 350
    },
    input_container: {
        marginTop: 7,
        borderWidth: 1,
        borderColor: constants.colors.border,
        borderRadius: 10,
        backgroundColor: constants.colors.inputBackground,
        paddingVertical: 5,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        width: "100%",
        paddingHorizontal: 10,
        paddingVertical: 2
    },
    input: {
        color: "#000",
        fontSize: 14,
        paddingHorizontal: 5,
        width: "90%",
        height: 35
    }
})