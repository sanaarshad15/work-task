import { TitleInput } from "./title-input";
import { Input } from "./input";
import { IconInput } from "./icon-input";

export const Inputs = {
    TitleInput,
    Input,
    IconInput
}