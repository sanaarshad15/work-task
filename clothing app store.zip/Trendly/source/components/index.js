import { CustomText as Text } from "./text";
import { Inputs } from "./inputs";
import { Buttons } from "./buttons";
import { Loader } from "./loader";

export const Components = {
    Text,
    Inputs,
    Buttons,
    Loader
}