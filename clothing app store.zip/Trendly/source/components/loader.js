import { View, ActivityIndicator } from "react-native";


export const Loader = () => {
    return (
        <View style={{ flex: 1, backgroundColor: "#f4f4f5", justifyContent: "center", alignItems: "center" }}>
            <ActivityIndicator size={'large'} color={'tomato'} />
        </View>
    )
}