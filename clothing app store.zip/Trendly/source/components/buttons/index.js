import { IconButton } from "./icon-button";
import { TextButton } from "./text-button";

export const Buttons = {
    IconButton,
    TextButton,
}