import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';

export function IconButton({ Icon, buttonStyle, ...props }) {
    return (
        <TouchableOpacity
            style={[styles.button, buttonStyle]}
            {...props}
        >
            {Icon}
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    button: {
        backgroundColor: '#007BFF',
        padding: 10,
        borderRadius: 5,
        alignItems: 'center',
        justifyContent:"center"
    },
});
