import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { CustomText } from '../text';

export function TextButton({ text, textStyle, buttonStyle, ...props }) {
    return (
        <TouchableOpacity
            style={[styles.button, buttonStyle]}
            {...props}
        >
            <CustomText.ButtonText text={text} textStyle={[styles.text, textStyle]} />
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    button: {
        backgroundColor: '#007BFF',
        padding: 10,
        borderRadius: 5,
        alignItems: 'center',
        justifyContent: "center"
    },
    text: {
        color: '#FFFFFF',
    },
});
