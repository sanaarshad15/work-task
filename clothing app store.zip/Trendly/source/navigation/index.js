import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import UnAuthStack from "./unauth";
import AuthStack from './auth';
import { useAuthContext } from '../context.js';


export default function MainNavigator() {
    const { user } = useAuthContext()


    return (
        <NavigationContainer>
            {user && user.auth ? <AuthStack /> : <UnAuthStack />}
        </NavigationContainer>
    );
}
