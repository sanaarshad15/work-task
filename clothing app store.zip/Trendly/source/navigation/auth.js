import React from "react";
import { StyleSheet, View } from "react-native";
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";

import { Components, } from "../components";
import { constants } from "../constants";

const Stack = createStackNavigator()

import Home from "../screens/auth/home";
import Orders from "../screens/auth/orders";
import Cart from "../screens/auth/cart";
import Account from "../screens/auth/account";
import Product from "../screens/auth/product";



const TabComp = ({ title, icon, focused }) => (
    <View style={[styles.tabCom]}>
        <Ionicons
            name={icon}
            size={16}
            color={focused ? 'tomato' : 'gray'}
        />
        <Components.Text.ButtonText
            text={title}
            textStyle={{ color: focused ? 'tomato' : 'gray', width: "100%" }}
        />
    </View>
)

const Tab = createBottomTabNavigator()

function TabNavigator() {
    return (
        <Tab.Navigator
            screenOptions={{
                headerShown: false,
                tabBarStyle: [styles.tabbar],
                tabBarShowLabel: false
            }}
        >
            <Tab.Screen name="home" component={Home}
                options={{
                    tabBarIcon: ({ size, focused, color }) => (
                        <TabComp
                            title={"Home"}
                            icon={focused ? 'home' : 'home-outline'}
                            focused={focused}
                        />
                    )
                }}
            />
            <Tab.Screen name="cart" component={Cart}
                options={{
                    tabBarIcon: ({ size, focused, color }) => (
                        <TabComp
                            title={"Cart"}
                            icon={focused ? 'cart-sharp' : 'cart-outline'}
                            focused={focused}
                        />
                    )
                }}
            />
            <Tab.Screen name="orders" component={Orders}
                options={{
                    tabBarIcon: ({ size, focused, color }) => (
                        <TabComp
                            title={"Orders"}
                            icon={focused ? 'receipt-sharp' : 'receipt-outline'}
                            focused={focused}
                        />
                    )
                }}
            />
            <Tab.Screen name="account" component={Account}
                options={{
                    tabBarIcon: ({ size, focused, color }) => (
                        <TabComp
                            title={"Account"}
                            icon={focused ? 'person-sharp' : 'person-outline'}
                            focused={focused}
                        />
                    )
                }}
            />
        </Tab.Navigator>
    )
}

export default function AuthStack() {
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }} initialRouteName="tab">
            <Stack.Screen name="tab" component={TabNavigator} />
            <Stack.Screen name="product" component={Product} />
        </Stack.Navigator>
    );
}



const styles = StyleSheet.create({
    tabbar: {
        height: 75,
        backgroundColor: constants.colors.inputBackground,
        width: "100%",
    },
    tabCom: {
        marginTop: 15,
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
    }
})