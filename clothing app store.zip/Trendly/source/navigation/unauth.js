import React from "react";
import { createStackNavigator } from '@react-navigation/stack';

const Stack = createStackNavigator()

import Signin from "../screens/unauth/signin";
import Signup from "../screens/unauth/signup";
import Reset from "../screens/unauth/reset";


export default function UnAuthStack() {
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }} initialRouteName="signin">
            <Stack.Screen name="signin" component={Signin} />
            <Stack.Screen name="signup" component={Signup} />
            <Stack.Screen name="reset" component={Reset} />
        </Stack.Navigator>
    );
}
