import { axiosRequests } from "./axios";

export const utils = {
    axiosRequests
}