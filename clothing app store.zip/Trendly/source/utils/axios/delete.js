import axios from "axios";
import { constants } from "../../constants";

export async function remove(token, endpoint) {
    try {
        const response = await axios.delete(`${constants.firebase.db}${endpoint}.json`, {
            params: { auth: token }
        });
        return { data: response.data, success: true }
    } catch (error) {
        return { data: null, success: false }
    }
}
