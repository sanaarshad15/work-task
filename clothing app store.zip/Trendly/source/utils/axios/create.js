import axios from "axios";
import { constants } from "../../constants";

export async function create(token, endpoint, data) {
    const base64Image = data.image;
    
    try {
        const response = await axios.put(`${constants.firebase.db}${endpoint}.json`, data, {
            params: { auth: token }
        })
        return { data: response.data, success: true }
    } catch (error) {
        console.error("Error Response:", error.response?.data || error.message);
        console.log('Error axios create', endpoint, error);
        return { data: null, success: false }
    }
}