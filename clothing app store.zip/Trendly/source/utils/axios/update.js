import axios from "axios";
import { constants } from "../../constants";

export async function update(token, path, data) {
    try {
        const response = await axios.patch(`${constants.firebase.db}${path}.json`, data, {
            params: { auth: token }
        });
        return { data: response.data, success: true }
    } catch (error) {
        return { data: null, success: false }
    }
}
