import axios from "axios";
import { constants } from "../../constants"


export async function read(token, path) {
    
    try {
        const response = await axios.get(`${constants.firebase.db}${path}.json`, {
            params: { auth: token }
        });
        return { data: response.data, success: true }
    } catch (error) {
        console.log(error)
        return { data: null, success: false }
    }
}
