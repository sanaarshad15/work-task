import { Components } from "../components";
import { constants } from "../constants";
import { useAuthContext, useProductContext, useCartContext } from "../context.js";
import { utils } from "../utils";

export {
    //  custom components inputs, text, buttons etc
    Components,
    //  constants for the app e-g colors
    constants,
    //  context hooks
    useAuthContext,
    useProductContext,
    useCartContext,
    utils

}