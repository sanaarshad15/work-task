import { useRef, useState } from "react";
import { View, StyleSheet, Image, TouchableOpacity, Alert } from "react-native";
import { constants, Components, utils, useAuthContext } from "../shared";
import axios from "axios";


export default function Signup({ navigation, route }) {

    const { updateUser } = useAuthContext()

    const [firstName, setFirstName] = useState();
    const firstNameRef = useRef(null);
    const [lastName, setLastName] = useState();
    const lastNameRef = useRef(null)
    const [email, setEmail] = useState()
    const emailRef = useRef(null);
    const [password, setPassword] = useState();
    const passwordRef = useRef(null);
    const [repeatPassword, setRepeatPassword] = useState();
    const repeatPasswordRef = useRef();


    function signup() {
        if (firstName !== undefined && constants.regexs.nameRegex.test(firstName)) {
            if (lastName !== undefined && constants.regexs.nameRegex.test(lastName)) {
                if (email !== undefined && constants.regexs.emailRegex.test(email)) {
                    if (password !== undefined && password.length >= 6) {

                        const url = `${constants.firebase.auth_url}signUp?key=${constants.firebase.API_KEY}`

                        if (repeatPassword !== undefined && repeatPassword === password) {
                            const response = axios.post(url, {
                                email: email,
                                password: password,
                                returnSecureToken: true,
                            }).then(async (response) => {
                                const user = {
                                    id: response.data.localId,
                                    email: email,
                                    password: password,
                                    firstName: firstName,
                                    lastName: lastName,
                                    address: '',
                                    phone: '',
                                    age: '',
                                    balance: 0
                                }
                                const profileResponse = await utils.axiosRequests.create(response.data.idToken, `Users/${response.data.localId}/Profile`, user);
                                if (profileResponse.success) {
                                    updateUser({ ...user, auth: true, token: response.data.idToken, refreshToken: response.data.refreshToken });
                                } else {
                                    Alert.alert('Unable to set up your profile, Please signin and try again in account tab.')
                                }
                            }).catch(err => {
                                console.log(err)
                                Alert.alert('Error', 'Unable to create account, Please try again.');
                            })

                        } else {
                            Alert.alert('Error', 'Passwords do not match')
                        }
                    } else {
                        Alert.alert('Error', 'Please enter a valid 6 or more character password')
                    }
                } else {
                    Alert.alert('Error', 'Please enter a valid email')
                }
            } else {
                Alert.alert('Error', 'Please enter a valid last name')
            }
        } else {
            Alert.alert('Error', 'Please enter a valid first name')
        }
    }

    return (
        <View style={[styles.container]}>
            <View style={[styles.header]}>
                <Image source={require("../../assets/images/logo.png")}
                    style={[styles.logo]}
                />
            </View>
            <View style={[styles.body]}>
                <Components.Text.Heading
                    text={"Trendly"}
                    textStyle={styles.heading}
                />
                <Components.Inputs.IconInput
                    setText={setFirstName}
                    value={firstName}
                    placeholder="Enter First Name"
                    title={"First Name"}
                    ref={firstNameRef}
                />
                <Components.Inputs.IconInput
                    setText={setLastName}
                    value={lastName}
                    placeholder="Enter Last Name"
                    title={"Last Name"}
                    ref={lastNameRef}
                    containerStyle={styles.inputContainer}
                />
                <Components.Inputs.IconInput
                    setText={setEmail}
                    value={email}
                    placeholder="Enter Email"
                    title={"Email"}
                    inputType="email"
                    ref={emailRef}
                    containerStyle={styles.inputContainer}
                />
                <Components.Inputs.IconInput
                    setText={setPassword}
                    value={password}
                    placeholder="Enter Password"
                    title={"Passwors"}
                    ref={passwordRef}
                    containerStyle={styles.inputContainer}
                />
                <Components.Inputs.IconInput
                    setText={setRepeatPassword}
                    value={repeatPassword}
                    placeholder="Enter Repeat Password"
                    title={"Repeat Password"}
                    ref={repeatPasswordRef}
                    containerStyle={styles.inputContainer}
                />
                <Components.Buttons.TextButton
                    text={"Signup"}
                    buttonStyle={styles.button}
                    onPress={signup}
                />
                <TouchableOpacity style={[styles.textButton]} onPress={() => {
                    navigation.goBack()
                }}>
                    <Components.Text.Body
                        text={"Already have an account?"}
                    />
                    <Components.Text.ButtonText
                        text={" Signin"}
                        textStyle={styles.touchText}
                    />
                </TouchableOpacity>
            </View>
            <View style={[styles.footer]}>
                <Components.Text.Body
                    text={"By signing up you agree to our "}
                />
                <View style={[styles.bottomTextContainer]}>
                    <TouchableOpacity style={[styles.textButton]}>
                        <Components.Text.Body
                            text={"Terms&Conditions"}
                            textStyle={styles.touchText}
                        />
                    </TouchableOpacity>
                    <Components.Text.Body
                        text={" and "}
                    />
                    <TouchableOpacity style={[styles.textButton]}>
                        <Components.Text.Body
                            text={"Privacy Policy"}
                            textStyle={styles.touchText}
                        />
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background,
    },
    header: {
        flex: 0.25,
        justifyContent: "center",
        alignItems: "center"
    },
    logo: {
        width: "100%",
        height: "100%",
        resizeMode: 'stretch'
    },
    body: {
        flex: 0.65,
        justifyContent: "flex-start",
        alignItems: "center",
    },
    heading: {
        marginTop: 5,
        fontStyle: "italic",
        textDecorationColor: "",
        fontSize: 50,
        letterSpacing: 5
    },
    inputContainer: {
        marginTop: 15
    },
    button: {
        width: 340,
        marginTop: 20
    },
    textButton: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        marginTop: 10
    },
    footer: {
        flex: 0.1,
        justifyContent: "center",
        alignItems: "center"
    },
    bottomTextContainer: {
        flexDirection: "row",
        alignItems: "baseline",
        marginTop: -5
    },
    touchText: {
        color: constants.colors.inputText
    }
})