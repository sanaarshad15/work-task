import { useRef, useState } from "react";
import { View, StyleSheet, TouchableOpacity, Alert } from "react-native";
import { constants, Components,} from "../shared";
import axios from "axios";


export default function Reset({ navigation, route }) {

    const [email, setEmail] = useState()
    const emailRef = useRef(null);

    function resetPassword() {
        if (email !== undefined && email.length > 0 && constants.regexs.emailRegex.test(email)) {
            try {
                const url = `${constants.firebase.auth_url}sendOobCode?key=${constants.firebase.API_KEY}`;
                const response = axios.post(url, {
                    requestType: "PASSWORD_RESET",
                    email: email
                });
                Alert.alert('Success','You can reset password via email link for your account.')
            } catch (error) {
                console.log(error);
                Alert.alert('Error', 'Unable to send password reset link, Please check your internet connection and try again')
            }
        } else {
            Alert.alert("Error", "Please enter a valid email");
        }
    }


    return (
        <View style={[styles.container]}>
            <View style={[styles.header]}>
                <TouchableOpacity onPress={() => { navigation.goBack() }}>
                    <Components.Text.ButtonText
                        text={"Back"}
                    />
                </TouchableOpacity>
                <Components.Text.Heading
                    text={"Forgot Password"}
                    textStyle={styles.heading}
                />
                <View />
            </View>
            <View style={[styles.body]}>

                <Components.Inputs.IconInput
                    setText={setEmail}
                    value={email}
                    placeholder="Enter Email"
                    title={"Email"}
                    ref={emailRef}
                />
                <Components.Buttons.TextButton
                    text={"Reset Password"}
                    buttonStyle={styles.button}
                    onPress={resetPassword}
                />
                <TouchableOpacity style={[styles.textButton]} onPress={() => {
                    navigation.goBack()
                }}>
                    <Components.Text.Body
                        text={"Password retrieved ?"}
                    />
                    <Components.Text.ButtonText
                        text={" Signin"}
                        textStyle={styles.touchText}
                    />
                </TouchableOpacity>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background,
    },
    header: {
        flex: 0.15,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: 15
    },
    heading: {
        marginTop: 5,
        fontSize: 20,
        letterSpacing: 2
    },
    body: {
        flex: 0.85,
        justifyContent: "flex-start",
        alignItems: "center",
    },
    inputContainer: {
        marginTop: 15
    },
    button: {
        width: 340,
        marginTop: 20
    },
    textButton: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        marginTop: 10
    },
})