import { useEffect, useRef, useState } from "react";
import { View, StyleSheet, Image, TouchableOpacity, Alert } from "react-native";
import { constants, Components, useAuthContext,utils } from "../shared";
import axios from "axios";


export default function Signin({ navigation, route }) {
    const { updateUser } = useAuthContext();

    const [email, setEmail] = useState('')
    const emailRef = useRef(null);
    const [password, setPassword] = useState('');
    const passwordRef = useRef(null);

    const [loading, setLoading] = useState(false)


    async function signin() {
        if (email !== undefined && email.length > 0 && constants.regexs.emailRegex.test(email)) {
            if (password !== undefined && password.length >= 6) {
                setLoading(true);
                const url = `${constants.firebase.auth_url}signInWithPassword?key=${constants.firebase.API_KEY}`;
                axios.post(url, {
                    email: email,
                    password: password,
                    returnSecureToken: true
                }).then(response => {
                    utils.axiosRequests.read(response.data.idToken, `Users/${response.data.localId}/Profile`).then(user => {
                        updateUser({ ...user.data, auth: true, token: response.data.idToken, refreshToken: response.data.refreshToken });
                        setLoading(false)
                    }).catch(err => {
                        console.log(err)
                        setLoading(false)
                    })
                }).catch(error => {
                    Alert.alert('Error', 'Please check your credentials and try again.')
                    setLoading(false)
                })
            } else {
                Alert.alert("Error", "Please enter a valid password")
            }
        } else {
            Alert.alert("Error", "Please enter a valid email")
        }
    }
    if (loading) {
        return <Components.Loader />
    }
    return (
        <View style={[styles.container]}>
            <View style={[styles.header]}>
                <Image source={require("../../assets/images/logo.png")}
                    style={[styles.logo]}
                />
            </View>
            <View style={[styles.body]}>
                <Components.Text.Heading
                    text={"Trendly"}
                    textStyle={styles.heading}
                />
                <Components.Inputs.IconInput
                    setText={setEmail}
                    value={email}
                    placeholder="Enter Email"
                    title={"Email"}
                    ref={emailRef}
                />
                <Components.Inputs.IconInput
                    setText={setPassword}
                    value={password}
                    placeholder="Enter Password"
                    title={"Password"}
                    ref={passwordRef}
                    containerStyle={styles.inputContainer}
                />
                <Components.Buttons.TextButton
                    text={"Signin"}
                    buttonStyle={styles.button}
                    onPress={signin}
                />
                <TouchableOpacity style={[styles.textButton]} onPress={() => {
                    navigation.navigate("signup")
                }}>
                    <Components.Text.Body
                        text={"Don't have an account?"}
                    />
                    <Components.Text.ButtonText
                        text={" Signup"}
                        textStyle={styles.touchText}
                    />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.textButton]} onPress={() => {
                    navigation.navigate("reset")
                }}>
                    <Components.Text.Body
                        text={"Don't remember your password?"}
                    />
                    <Components.Text.ButtonText
                        text={" Reset"}
                        textStyle={styles.touchText}
                    />
                </TouchableOpacity>
            </View>
            <View style={[styles.footer]}>
                <Components.Text.Body
                    text={"By signing in you agree to our "}
                />
                <View style={[styles.bottomTextContainer]}>
                    <TouchableOpacity style={[styles.textButton]}>
                        <Components.Text.Body
                            text={"Terms&Conditions"}
                            textStyle={styles.touchText}
                        />
                    </TouchableOpacity>
                    <Components.Text.Body
                        text={" and "}
                    />
                    <TouchableOpacity style={[styles.textButton]}>
                        <Components.Text.Body
                            text={"Privacy Policy"}
                            textStyle={styles.touchText}
                        />
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background,
    },
    header: {
        flex: 0.35,
        justifyContent: "center",
        alignItems: "center"
    },
    logo: {
        width: "100%",
        height: "100%",
        resizeMode: 'stretch'
    },
    body: {
        flex: 0.45,
        justifyContent: "flex-start",
        alignItems: "center",
        justifyContent: "center"
    },
    heading: {
        marginTop: 5,
        fontStyle: "italic",
        textDecorationColor: "",
        fontSize: 50,
        letterSpacing: 5
    },
    inputContainer: {
        marginTop: 15
    },
    button: {
        width: 340,
        marginTop: 20
    },
    textButton: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        marginTop: 10
    },
    footer: {
        flex: 0.2,
        justifyContent: "center",
        alignItems: "center"
    },
    bottomTextContainer: {
        flexDirection: "row",
        alignItems: "baseline",
        marginTop: -5
    },
    touchText: {
        color: constants.colors.inputText
    }
})