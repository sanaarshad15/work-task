import { useRef, useState } from "react";
import { View, StyleSheet, SafeAreaView, Platform, TouchableWithoutFeedback, Keyboard, Alert, } from "react-native";
import { Components, constants, useAuthContext, auth, utils } from "../shared";


export default function Account({ navigation, route }) {

    const { user, updateUser } = useAuthContext();
    const [loading, setLoading] = useState(false);

    const [age, setAge] = useState(user.age);
    const ageRef = useRef(null);
    const [address, setAddress] = useState(user.address);
    const addressRef = useState();
    const [phone, setPhone] = useState(user.phone);
    const phoneRef = useRef();

    async function updateAccount() {
        let finalAddress = address !== undefined ? address : user.address;
        let finalAge = age !== undefined ? age : user.age;
        let finalPhone = phone !== undefined ? phone : user.phone;
        if (finalAge && finalAge.length > 0) {
            if (!constants.regexs.ageRegex.test(age)) {
                Alert.alert('Error', 'Please enter a valid age between 0-120')
            }
        }
        if (finalPhone && finalPhone.length > 0) {
            if (!constants.regexs.phoneRegex.test(phone)) {
                Alert.alert('Error', 'Please enter a valid pakistan phone number')
            }
        }
        setLoading(true);
        try {
            const response = await utils.axiosRequests.update(user.token, `Users/${user.id}/Profile`, {
                address: finalAddress,
                age: finalAge,
                phone: finalPhone
            })
            if (response.success) {
                updateUser({
                    ...user, address: finalAddress,
                    age: finalAge,
                    phone: finalPhone
                })
                Alert.alert('Success', 'Account updated successfully')
            } else {
                Alert.alert('Error', 'Unable to update user profile, Please try again');
            }
        } catch (error) {
            console.log(error)
            Alert.alert('Error', 'Unable to update user profile, Please try again');
        } finally {
            setLoading(false)
        }
    }

    const InfoComp = ({ title, value }) => {
        return (
            <View style={[styles.info_container]}>
                <Components.Text.SubHeading
                    text={title}
                    textStyle={styles.info_heading}
                />
                <View style={[styles.info_text_contaienr, { backgroundColor: `${constants.colors.inputBackground}90` }]}>
                    <Components.Text.Body
                        text={value}
                        textStyle={styles.info_text}
                    />
                </View>
            </View>
        )
    }
    if (loading) {
        return <Components.Loader />
    }
    return (
        <TouchableWithoutFeedback style={{ flex: 1 }}
            onPress={() => { Keyboard.dismiss() }}
        >
            <View style={[styles.container]}>
                <SafeAreaView style={{ flex: 1 }}>
                    <InfoComp title={'First Name'} value={user.firstName} />
                    <InfoComp title={'Last Name'} value={user.lastName} />
                    <InfoComp title={'Email'} value={user.email} />
                    <InfoComp title={'Credit'} value={user.balance} />
                    <Components.Inputs.TitleInput
                        title={'Age'}
                        setText={setAge}
                        ref={ageRef}
                        value={age}
                        placeholder={"Enter your age"}
                        style={styles.info_text_contaienr}
                        containerStyle={styles.info_container}
                        inputMode='numeric'
                    />
                    <Components.Inputs.TitleInput
                        title={'Phone'}
                        setText={setPhone}
                        ref={phoneRef}
                        value={phone}
                        placeholder={"Enter your phone"}
                        style={styles.info_text_contaienr}
                        containerStyle={styles.info_container}
                        inputMode='numeric'
                    />
                    <Components.Inputs.TitleInput
                        title={'Address'}
                        setText={setAddress}
                        ref={addressRef}
                        value={address}
                        placeholder={"Enter your address"}
                        style={styles.info_text_contaienr}
                        containerStyle={styles.info_container}
                    />
                    <Components.Buttons.TextButton
                        text={'Update'}
                        buttonStyle={styles.button}
                        onPress={updateAccount}
                    />
                    <Components.Buttons.TextButton
                        text={'Signout'}
                        buttonStyle={styles.button}
                        onPress={() => {
                           updateUser(null)
                        }}
                    />
                </SafeAreaView>
            </View>
        </TouchableWithoutFeedback>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background,
        paddingVertical: Platform.OS === "ios" ? 0 : 25,
        paddingHorizontal: 15
    },
    info_container: {
        marginTop: 10
    },
    info_heading: {
        color: constants.colors.text
    },
    info_text_contaienr: {
        marginTop: 5,
        backgroundColor: constants.colors.inputBackground,
        paddingVertical: 10,
        paddingHorizontal: 5,
        borderRadius: 10,
        width: "100%",
    },
    info_text: {
        fontSize: 15,
        color: constants.colors.text
    },
    button: {
        marginTop: 15
    }
})