import { useEffect, useState } from "react";
import { View, Alert, StyleSheet, Platform, ScrollView, } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Components, constants, useAuthContext, useCartContext, useProductContext,utils } from "../shared";
import axios from "axios";


export default function Cart({ navigation, route }) {
    const { user } = useAuthContext()
    const { cartContent, updateCart } = useCartContext();
    const { products } = useProductContext();
    //  sub total cost of purchase only
    const [total, setTotal] = useState(0);
    //  tax
    const [tax, setTax] = useState(0);

    useEffect(() => {
        if (Object.values(cartContent).length > 0) {
            let total = 0;
            Object.values(cartContent).forEach((item, index) => {
                total = total + item.quantity * products[item.id].price;
            });
            //  17% gst
            const tax = (total / 100) * 17
            setTax(tax);

            setTotal(total)
        }
    }, [cartContent]);


    async function placeOrder() {
        const finalProducts = Object.values(cartContent).map((item) => {
            return {
                id: item.id,
                name: products[item.id].name,
                quantity: item.quantity,
                total: item.quantity * products[item.id].price,
            };
        });

        const finalPrice = total + tax + 200;
        const orderData = {
            products: finalProducts,
            subTotal: total,
            tax: tax,
            deliveryFee: 200,
            address: user.address,
            userId: user.id,
            status: 'Pending',
            total: finalPrice,
            placedAt: new Date().getTime(),
            updatedAt: new Date().getTime(),
        };
        try {
            const response = await axios.post(`${constants.firebase.db}Orders.json`, orderData, {
                params: { auth: user.token }
            })

            if (response.data) {
                Alert.alert('Success', 'Order placed, You can check order status in the orders tab');
                updateCart({});
                setTotal(0);
                setTax(0);
            } else {
                Alert.alert('Error', 'Unable to place order, please try again');
            }
        } catch (error) {
            console.error('Error placing order:', error);
            Alert.alert('Error', 'Unable to place order, please try again');
        }
    }



    function addToCart(id) {
        const cart = { ...cartContent };
        const productInCart = cart[id] !== undefined ? cart[id] : { id: id, quantity: 0 };
        if (productInCart.quantity === Number(products[id].quantity)) {
            Alert.alert('Error', 'You cannot add anymore of this product.')
        } else {
            productInCart.quantity = productInCart.quantity + 1;
            cart[id] = productInCart;
            updateCart(cart);
        }
    }
    function removeFromCart(id) {
        const cart = { ...cartContent };
        if (cart[id] !== undefined) {
            const productInCart = cart[id];
            productInCart.quantity = productInCart.quantity - 1;
            if (productInCart.quantity <= 0) {
                delete cart[id];
            } else {
                cart[id] = productInCart;
            }
            updateCart(cart);
        }
    }

    return (
        <View style={[styles.container]}>
            <View style={[styles.header]}>
                <Components.Text.Heading
                    text={'Checkout'}
                    textStyle={{ marginTop: 20 }}
                />
            </View>
            <View style={[styles.body]}>
                {
                    Object.keys(cartContent).length === 0 ?
                        <View style={{ flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: constants.colors.background, paddingHorizontal: 10 }}>
                            <Components.Text.SubHeading
                                text={'Oops it looks like your cart is empyt, Start shopping ?'}
                                textStyle={{ textAlign: "center", width: "50%" }}
                            />
                            <Components.Buttons.TextButton
                                text={'Start Shopping'}
                                onPress={() => { navigation.navigate('home') }}
                                buttonStyle={[styles.order_button, { width: "90%" }]}
                            />
                        </View>
                        :
                        <ScrollView style={{ flex: 1, flexGrow: 1 }}>
                            <View style={[styles.order_card]}>
                                <Components.Text.SubHeading
                                    text={'Your Shopping list: '}

                                />
                                <View style={[styles.list]}>
                                    {
                                        Object.keys(cartContent).map((item, index) => {
                                            return (
                                                <View style={[styles.item]} key={index}>
                                                    <View style={{ flex: 0.55 }}>
                                                        <Components.Text.ButtonText
                                                            text={products[item].name}
                                                            textStyle={styles.product_name}
                                                        />
                                                    </View>
                                                    <View style={{ flex: 0.15, flexDirection: "row", alignItems: "center" }}>
                                                        <Ionicons
                                                            name="remove-circle-sharp"
                                                            size={16}
                                                            color={'gray'}
                                                            onPress={() => {
                                                                removeFromCart(item);
                                                            }}
                                                        />
                                                        <Components.Text.ButtonText
                                                            text={cartContent[item] !== undefined ? cartContent[item].quantity : 0}
                                                            textStyle={styles.quantity}
                                                        />
                                                        <Ionicons
                                                            name="add-circle-sharp"
                                                            size={16}
                                                            color={'tomato'}
                                                            onPress={() => {
                                                                addToCart(item)
                                                            }}
                                                        />
                                                    </View>
                                                    <View style={{ flex: 0.3, justifyContent: "flex-end", alignItems: "flex-end" }}>
                                                        <Components.Text.Body
                                                            text={`PKR ${cartContent[item].quantity * products[item].price}`}
                                                        />
                                                    </View>
                                                </View>
                                            )
                                        })
                                    }
                                    <View style={[styles.amount_Container]}>
                                        <View style={[styles.total_view]}>
                                            <Components.Text.SubHeading
                                                text={'Sub-total'}
                                                textStyle={styles.amount_title}
                                            />
                                            <Components.Text.SubHeading
                                                text={`PKR ${total}`}
                                                textStyle={styles.amount_value}
                                            />
                                        </View>
                                        <View style={[styles.total_view]}>
                                            <Components.Text.SubHeading
                                                text={'Tax (17% GST)'}
                                                textStyle={styles.amount_title}
                                            />
                                            <Components.Text.SubHeading
                                                text={`PKR ${tax}`}
                                                textStyle={styles.amount_value}
                                            />
                                        </View>
                                        <View style={[styles.total_view]}>
                                            <Components.Text.SubHeading
                                                text={'Total (incl. tax & delivery fee ) '}
                                                textStyle={[styles.amount_title, { color: '#000' }]}
                                            />
                                            <Components.Text.SubHeading
                                                text={`PKR ${tax + total + 200}`}
                                                textStyle={styles.amount_value}
                                            />
                                        </View>
                                    </View>
                                    <View style={[styles.address_conatiner]}>
                                        <Components.Text.SubHeading
                                            text={'Delivery Address: '}
                                        />
                                        <View style={{ flexDirection: "row", alignItems: "center" }}>
                                            <Components.Text.Body
                                                text={user.address && user.address.trim().length > 0 ? user.address : 'Please add an address before proceeding'}
                                                textStyle={styles.address}
                                            />
                                            <Ionicons
                                                name="pencil-sharp"
                                                color={constants.colors.buttonText}
                                                size={15}
                                                style={{ backgroundColor: `${constants.colors.buttons}`, padding: 5, borderRadius: 4 }}
                                                onPress={() => { navigation.navigate('account') }}
                                            />
                                        </View>
                                    </View>
                                    {
                                        user.address && user.address.trim().length > 0 ?
                                            <Components.Buttons.TextButton
                                                text={'Place Order'}
                                                buttonStyle={styles.order_button}
                                                onPress={placeOrder}
                                            /> :
                                            null
                                    }
                                </View>
                            </View>
                        </ScrollView>
                }
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background
    },
    header: {
        flex: Platform.OS === "ios" ? 0.15 : 0.1,
        backgroundColor: constants.colors.card,
        justifyContent: "center",
        alignItems: "center",
    },
    body: {
        flex: Platform.OS === "ios" ? 0.85 : 0.9
    },
    order_card: {
        flex: 1,
        backgroundColor: constants.colors.card,
        marginTop: 10,
        paddingVertical: 10,
        paddingHorizontal: 10
    },
    list: {
        paddingHorizontal: 5,
        height: "96%"
    },
    item: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginVertical: 10
    },
    product_name: {
        fontSize: 11,
        fontWeight: '600',
        textAlign: 'left'
    },
    quantity: {
        marginHorizontal: 5,
        fontSize: 11
    },
    amount_Container: {
        borderStyle: 'solid',
        borderTopColor: constants.colors.border,
        borderTopWidth: 1,
        paddingTop: 15,
        marginTop: 15,
        paddingBottom: 10
    },
    total_view: {
        marginTop: 5,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },
    amount_title: {
        color: 'gray',
        fontSize: 14,
        fontWeight: '600'
    },
    amount_value: {
        color: 'tomato',
        fontSize: 13,
        fontWeight: '500'
    },
    address_conatiner: {
        marginTop: 10
    },
    address: {
        width: "90%",
        textAlign: 'left',
        fontSize: 11,
        fontWeight: 400
    },
    order_button: {
        marginTop: 15,
    }
})