import { useEffect, useRef, useState } from "react";
import { View, FlatList, StyleSheet, Image, TouchableOpacity, SafeAreaView, Platform, Alert } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Components, constants, useCartContext, useProductContext } from "../shared";


export default function Home({ navigation, route }) {

    const { categories, products } = useProductContext();
    const { cartContent, updateCart } = useCartContext();

    const [searched, setSearched] = useState();
    const searchedRef = useRef(null);

    const [selectedCategory, setSelectedCategory] = useState(0);



    function addToCart(id) {
        const cart = { ...cartContent };
        const productInCart = cart[id] !== undefined ? cart[id] : { id: id, quantity: 0 };
        if (productInCart.quantity === Number(products[id].quantity)) {
            Alert.alert('Error', 'You cannot add anymore of this product.')
        } else {
            productInCart.quantity = productInCart.quantity + 1;
            cart[id] = productInCart;
            updateCart(cart);
        }
    }
    function removeFromCart(id) {
        const cart = { ...cartContent };
        if (cart[id] !== undefined) {
            const productInCart = cart[id];
            productInCart.quantity = productInCart.quantity - 1;
            if (productInCart.quantity <= 0) {
                delete cart[id];
            } else {
                cart[id] = productInCart;
            }
            updateCart(cart);
        }
    }


    function RenderProducts() {
        // get products in the category and in case of all get all products
        const productsInCategory = Object.values(products).map((product) => {
            if (selectedCategory === 0) {
                return product
            } else if (product.category === selectedCategory) {
                return product
            }
        })
        // get searched products in case of no product being searched return all category products
        const searchedProducts = productsInCategory.map((product) => {
            if (searched && searched.length > 0) {
                if (product.name.toLowerCase().includes(searched.toLowerCase())) {
                    return product
                }
            } else {
                return product
            }
        })
        return (
            <View style={[styles.section]}>
                <FlatList
                    showsVerticalScrollIndicator={false}
                    data={searchedProducts}
                    numColumns={2}
                    keyExtractor={(item, index) => String(index)}
                    renderItem={({ item, index }) => {
                        if (item) {
                            return (
                                <View style={[styles.product]} >
                                    <Image
                                        source={constants.productImages[item.image].path}
                                        style={[styles.product_image]}
                                    />
                                    <View style={{ marginTop: 10, paddingHorizontal: 5 }}>
                                        <Components.Text.SubHeading
                                            text={item.name}
                                            textStyle={styles.product_name}
                                        />
                                        <Components.Text.Body
                                            text={`${item.description.substring(0, 67)}...`}
                                            textStyle={styles.description}
                                        />
                                        <View style={{ marginTop: 10, flexDirection: "row", alignItems: "center", justifyContent: "space-between", width: "99%" }}>
                                            <Components.Text.Body
                                                text={item.quantity === 0 ? 'Out of Stock' : `PKR ${item.price}`}
                                                textStyle={styles.product_price}
                                            />
                                            <View style={[styles.selection_view]}>
                                                <Ionicons
                                                    name="remove-circle-sharp"
                                                    size={20}
                                                    color={'gray'}
                                                    onPress={() => {
                                                        removeFromCart(item.id);
                                                    }}
                                                />
                                                <Components.Text.ButtonText
                                                    text={cartContent[item.id] !== undefined ? cartContent[item.id].quantity : 0}
                                                    textStyle={styles.quantity}
                                                />
                                                <Ionicons
                                                    name="add-circle-sharp"
                                                    size={20}
                                                    color={'tomato'}
                                                    onPress={() => {
                                                        addToCart(item.id)
                                                    }}
                                                />
                                            </View>
                                        </View>
                                        <View style={{ alignItems: "center", justifyContent: "center", marginTop: 10 }}>
                                            <Ionicons
                                                name="arrow-forward-circle"
                                                size={30}
                                                color={constants.colors.buttons}
                                                onPress={() => {
                                                    navigation.navigate("product", { id: item.id })
                                                }}
                                            />
                                        </View>
                                    </View>
                                </View>
                            )
                        }
                    }}
                />
            </View>
        )
    }

    return (
        <View style={[styles.container]}>
            <View style={[styles.header]}>
                <SafeAreaView style={[styles.safeHeader]}>
                    <Components.Inputs.Input
                        onChangeText={setSearched}
                        value={searched}
                        ref={searchedRef}
                        style={[styles.searchInput]}
                        placeholder={'Search products by name'}
                    />
                    <Components.Buttons.TextButton
                        text={'Clear'}
                        onPress={() => { setSearched(undefined); searchedRef.current.clear() }}
                    />
                </SafeAreaView>
            </View>
            <View style={[styles.body]}>
                <View style={{ flex: 0.1 }}>
                    <FlatList
                        showsVerticalScrollIndicator={false}
                        data={[0].concat(Object.keys(categories))}
                        keyExtractor={(item, index) => item}
                        horizontal
                        renderItem={({ item, index }) => {
                            return <Components.Buttons.TextButton
                                text={item === 0 ? 'All' : categories[item].name}
                                buttonStyle={selectedCategory === item ? styles.category : [styles.category, { backgroundColor: constants.colors.background }]}
                                textStyle={selectedCategory === item ? styles.category_text : [styles.category_text, { color: constants.colors.buttons }]}
                                onPress={() => { setSelectedCategory(item === 0 ? 0 : item) }}
                            />
                        }}
                    />
                </View>
                <View style={{ flex: 0.9 }}>
                    <RenderProducts />
                </View>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background
    },
    header: {
        flex: Platform.OS === "ios" ? 0.15 : 0.1,
        backgroundColor: constants.colors.card,
        paddingHorizontal: 10
    },
    safeHeader: {
        marginTop: Platform.OS === "ios" ? 0 : 30,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },
    searchInput: {
        width: "80%",
        borderRadius: 10,
        paddingVertical: 10
    },
    searchButton: {

    },
    body: {
        flex: Platform.OS === "ios" ? 0.85 : 0.9,
        backgroundColor: constants.colors.background,
        paddingVertical: 10,
        paddingHorizontal: 10
    },
    category: {
        height: 40,
        marginRight: 10,
        justifyContent: "center",
        alignItems: "center",
        borderWidth: 1,
        borderColor: constants.colors.buttons
    },
    category_text: {
        fontWeight: 500,
        fontSize: 15
    },
    product: {
        alignItems: "center",
        flex: 0.5,
        backgroundColor: constants.colors.card,
        borderRadius: 5,
        height: 265
    },
    product_image: {
        height: 100,
        width: '100%',
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
        resizeMode: 'stretch',
    },
    product_name: {
        color: '#000',
    },
    description: {
        fontWeight: "400",
        fontSize: 12
    },
    product_price: {
        fontSize: 12,
        color: "tomato"
    },
    selection_view: {
        flexDirection: "row",
        alignItems: "center",
        alignSelf: "center",
    },
    quantity: {
        width: 30,
        fontSize: 10,
        textAlign: "center",
        marginHorizontal: 0
    }
})


// if (categoryProduct.length > 0) {
//     return (
//      
//     )
// } else {
//     return null
// }
// }}