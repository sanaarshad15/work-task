import { useEffect, useState } from "react";
import { View, StyleSheet, Image, Platform, SafeAreaView, ScrollView, } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Components, constants, useProductContext, useCartContext } from "../shared";


export default function Product({ navigation, route }) {

    const [product, setProduct] = useState();
    const { products, categories } = useProductContext();
    const { cartContent, updateCart } = useCartContext();

    useEffect(() => {
        setProduct(products[route.params.id])
    }, [route.params.id])

    function addToCart(id) {
        const cart = { ...cartContent };
        const productInCart = cart[id] !== undefined ? cart[id] : { id: id, quantity: 0 };
        if (productInCart.quantity === Number(products[id].quantity)) {
            Alert.alert('Error', 'You cannot add anymore of this product.')
        } else {
            productInCart.quantity = productInCart.quantity + 1;
            cart[id] = productInCart;
            updateCart(cart);
        }
    }
    function removeFromCart(id) {
        const cart = { ...cartContent };
        if (cart[id] !== undefined) {
            const productInCart = cart[id];
            productInCart.quantity = productInCart.quantity - 1;
            if (productInCart.quantity <= 0) {
                delete cart[id];
            } else {
                cart[id] = productInCart;
            }
            updateCart(cart);
        }
    }


    if (!product) {
        return <Components.Loader />
    }
    if (product) {
        return (
            <View style={[styles.container]}>
                <View style={[styles.header]}>
                    <SafeAreaView style={[styles.safeHeader]}>
                        <Ionicons
                            name="arrow-back-circle-sharp"
                            color={constants.colors.buttons}
                            size={24}
                            onPress={() => { navigation.goBack() }}
                        />
                    </SafeAreaView>
                </View>
                <View style={[styles.body]}>
                    <ScrollView style={{ flex: 1, flexGrow: 1 }}>
                        <Image
                            source={constants.productImages[product.image].path}
                            style={[styles.product_image]} />
                        <View style={[styles.product_header]}>
                            <Components.Text.Heading
                                text={product.name}
                            />
                            <Components.Text.Body
                                text={`PKR ${product.price}`}
                                textStyle={{ color: 'tomato' }}
                            />
                        </View>
                        <View>
                            <Components.Text.Body
                                text={product.description}
                                textStyle={styles.description}
                            />
                        </View>
                    </ScrollView>
                    <View style={[styles.cart_selection]}>
                        <View style={[styles.selection_view]}>
                            <Ionicons
                                name="remove-circle-sharp"
                                size={30}
                                color={'gray'}
                                onPress={() => {
                                    removeFromCart(product.id);
                                }}
                            />
                            <Components.Text.ButtonText
                                text={cartContent[product.id] !== undefined ? cartContent[product.id].quantity : 0}
                                textStyle={styles.quantity}
                            />
                            <Ionicons
                                name="add-circle-sharp"
                                size={30}
                                color={'tomato'}
                                onPress={() => {
                                    addToCart(product.id)
                                }}
                            />
                        </View>
                    </View>
                </View>
            </View >
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background
    },
    header: {
        flex: Platform.OS == "ios" ? 0.1 : 0.08,
        paddingHorizontal: 5,
    },
    safeHeader: {
        flex: 1,
        marginTop: Platform.OS === "ios" ? 0 : 40,

    },
    body: {
        flex: Platform.OS == "ios" ? 0.9 : 0.95,
        paddingHorizontal: 10
    },
    product_image: {
        marginTop: 10,
        height: 350,
        width: "100%",
        resizeMode: 'stretch',
        alignSelf: "center",
        borderRadius: Platform.OS === "ios" ? 5 : 2,
    },
    product_header: {
        alignItems: "flex-start",
        justifyContent: "space-between",
        marginTop: 5
    },
    description: {
        fontSize: 13,
        fontWeight: 400,
        marginTop: 10
    },
    cart_selection: {
        position: "absolute",
        top: "90%",
        justifyContent: "center",
        alignItems: "center",
        width: "100%"
    },
    selection_view: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    quantity: {
        fontSize: 15,
        fontWeight: '600',
        marginHorizontal: 10
    }
})