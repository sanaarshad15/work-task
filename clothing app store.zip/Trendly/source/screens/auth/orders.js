import { useEffect, useState } from "react";
import { View, FlatList, StyleSheet, SafeAreaView, } from "react-native";
import { constants, Components, useAuthContext } from "../shared";
import axios from "axios";

export default function Orders({ navigation, route }) {
    const { user } = useAuthContext()
    const [orders, setOrders] = useState([]);

    async function getOrders() {
        const params = {
            auth: user.token,
            orderBy: '"userId"',
            equalTo: `"${user.id}"`
        };
        try {
            const response = await axios.get(`${constants.firebase.db}Orders.json`, { params });
            if (response.data) {
                let tempOrders = []
                Object.keys(response.data).forEach((item, index) => {
                    tempOrders.push({ ...response.data[item], id: item })
                })
                setOrders(tempOrders)
            }
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        if (user && user.auth) {
            if (true) {
                getOrders()
            }
        }
    }, [user])



    return (
        <View style={[styles.container]}>
            <SafeAreaView style={{ flex: 1 }}>
                <FlatList
                    data={orders}
                    keyExtractor={(item, index) => String(index)}
                    renderItem={({ item, index }) => {
                        if (item) {
                            return (
                                <View style={[styles.order_container]}>
                                    <View style={[styles.order_header]}>
                                        <Components.Text.SubHeading
                                            text={`Order id #${item.id}`}
                                            textStyle={{ color: '#000' }}
                                        />
                                        <Components.Text.SubHeading
                                            text={item.status}
                                            textStyle={{ color: 'tomato' }}
                                        />
                                    </View>
                                    <View style={[styles.user_info]}>
                                        <Components.Text.Body
                                            text={`Name: ${user.firstName} ${user.lastName}`}
                                            textStyle={styles.info_text}
                                        />
                                        <Components.Text.Body
                                            text={`Address: ${item.address}`}
                                            textStyle={styles.info_text}
                                        />
                                        <Components.Text.Body
                                            text={`Payment: Cash on Delivery`}
                                            textStyle={styles.info_text}
                                        />
                                    </View>
                                    <View>
                                        <Components.Text.SubHeading
                                            text={`Order Details`}
                                            textStyle={{ color: '#000', paddingBottom: 5 }}

                                        />
                                        {
                                            item.products.map((item, index) => {
                                                return (
                                                    <View style={[styles.product_container]} key={index}>
                                                        <Components.Text.Body
                                                            text={item.name}
                                                            textStyle={styles.product_name}
                                                        />
                                                        <Components.Text.Body
                                                            text={`${item.quantity}`}
                                                            textStyle={styles.product_quantity}
                                                        />
                                                        <Components.Text.Body
                                                            text={`PKR ${item.total}`}
                                                            textStyle={styles.product_price}
                                                        />
                                                    </View>
                                                )
                                            })
                                        }
                                    </View>
                                    <View style={[styles.amount_Container]}>
                                        <View style={[styles.total_view]}>
                                            <Components.Text.SubHeading
                                                text={'Sub-total'}
                                                textStyle={styles.amount_title}
                                            />
                                            <Components.Text.SubHeading
                                                text={`PKR ${item.subTotal}`}
                                                textStyle={styles.amount_value}
                                            />
                                        </View>
                                        <View style={[styles.total_view]}>
                                            <Components.Text.SubHeading
                                                text={'Tax (17% GST)'}
                                                textStyle={styles.amount_title}
                                            />
                                            <Components.Text.SubHeading
                                                text={`PKR ${item.tax}`}
                                                textStyle={styles.amount_value}
                                            />
                                        </View>
                                        <View style={[styles.total_view]}>
                                            <Components.Text.SubHeading
                                                text={'Total (incl. tax & delivery fee ) '}
                                                textStyle={[styles.amount_title, { color: '#000' }]}
                                            />
                                            <Components.Text.SubHeading
                                                text={`PKR ${item.total}`}
                                                textStyle={styles.amount_value}
                                            />
                                        </View>
                                    </View>
                                    <View style={[styles.date_cotnainer]}>
                                        <Components.Text.Body
                                            text={`Placed at: ${String(new Date(item.placedAt))}`}
                                            textStyle={styles.date_text}
                                        />
                                        {
                                            item.status === 'Delivered' ?
                                                <Components.Text.Body
                                                    text={`Delivered at: ${String(new Date(item.updatedAt))}`}
                                                    textStyle={styles.date_text}
                                                /> :
                                                null
                                        }
                                    </View>
                                </View>
                            )
                        } else {
                            return null
                        }
                    }}
                />
            </SafeAreaView>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: constants.colors.background,
        paddingTop: 30,
        paddingHorizontal: 5
    },
    order_container: {
        backgroundColor: constants.colors.card,
        paddingVertical: 10,
        paddingHorizontal: 10,
        borderRadius: 5,
        marginTop: 15
    },
    order_header: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    user_info: {
        marginVertical: 10
    },
    info_text: {
        marginVertical: 1
    },
    product_container: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    product_name: {
        fontSize: 12,
        fontWeight: '400',
        color: '#000'
    },
    product_quantity: {
        fontSize: 12,
        fontWeight: '400',
        color: '#000'
    },
    product_price: {
        fontSize: 12,
        fontWeight: '400',
        color: 'tomato'
    },
    amount_Container: {
        marginTop: 10,
        paddingTop: 10,
        borderTopWidth: 2,
        borderColor: constants.colors.border
    },
    total_view: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginVertical: 2
    },
    amount_title: {
        fontSize: 11,
    },
    amount_value: {
        fontSize: 11,
        color: 'tomato'
    },
    date_cotnainer: {
        paddingVertical: 5
    },
    date_text: {
        color: '#000',
        marginTop: 10
    }
})